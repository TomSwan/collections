//==============================================================
// coordinate.cpp -- Implements the TCoordinate class
// Time-stamp: <1999-06-15 11:00:18 tswan>
// To compile:
//   g++ -c coordinate.cpp
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include "coordinate.h"

void TCoordinate::Setxy(int x, int y)
{
  tc_x = x;
  tc_y = y;
}

int TCoordinate::Getx() const
{
  return tc_x;
}

int TCoordinate::Gety() const
{
  return tc_y;
}
