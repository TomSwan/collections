//==============================================================
// coordinate.h -- Declarations for TCoordinate class
// Time-stamp: <1999-06-15 11:00:42 tswan>
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#ifndef __coordinate_H
#define __coordinate_H   // Prevent multiple #includes

class TCoordinate {
private:
  int tc_x, tc_y;
public:
  TCoordinate(): tc_x(0), tc_y(0) { }
  TCoordinate(int x, int y): tc_x(x), tc_y(y) { }
  void Setxy(int x, int y);
  int Getx() const;
  int Gety() const;
};

#endif  // __coordinate_H

