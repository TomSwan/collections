//==============================================================
// localexcept.cpp -- Local variables and exceptions
// Time-stamp: <1999-06-18 16:56:45 tswan>
// To compile:
//   g++ localexcept.cpp
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>
#include <exception>

class A {
public:
  A() { cout << "A constructor" << endl; }
 ~A() { cout << "A destructor" << endl; }
};

void f();

int main()
{
  try {
    f();
  }
  catch (const char *s) {
    cout << s << endl;
  }
  return 0;
}

void f()
{
  A a;  // Construct object of class A
  throw ("Error condition");
}

