//==============================================================
// substring.cpp -- Demonstrate string object substring searches
// Time-stamp: <1999-07-07 09:34:03 tswan>
// To compile:
//   g++ substring.cpp
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>
#include <string>
#include <stdexcept>

int main()
{
  string findme;
  cout << "Enter substring to find: ";
  cin >> findme;

  string sobject("abcdefghijklmnopqrstuvwxyz");
  int len = sobject.length();
  
  try {
    int pos = 0;
    while (pos <= len) {
      if (sobject.compare(findme, pos, findme.length() ) == 0) {
        cout << "Match at pos == " << pos << endl;
        exit(0);
      }
      pos++;
    }
  }
  catch (out_of_range error) {
    cout << "*** Error: " << error.what() << endl;
    exit(1);
  }

  return 0;
}
