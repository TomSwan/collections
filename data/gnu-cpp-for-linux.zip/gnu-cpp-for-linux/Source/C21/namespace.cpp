//==============================================================
// namespace.cpp -- Demonstrates namespaces
// Time-stamp: <1999-07-02 13:03:07 tswan>
// To compile:
//   g++ namespace.cpp
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>

namespace FOREIGNER {
class TAnyClass {
public:
  int q;
  TAnyClass() { q = 0; }
};
}  // namespace FOREIGNER

namespace TSWAN {

class TAnyClass {
  int x, y, z;
public:
  TAnyClass() { x = 0; y = 0; z = 0; }
  void SetXYZ(int X, int Y, int Z) {
    x = X; y = Y; z = Z;
  }
  void Display(void) {
    cout << "x == " << x << endl;
    cout << "y == " << y << endl;
    cout << "z == " << z << endl;
  }
};

int main()
{
  TAnyClass v1;
  v1.SetXYZ(123, 234, 345);
  v1.Display();
  FOREIGNER::TAnyClass v2;
  cout << "v2.q == " << v2.q << endl;
  return 0;
}

} // namespace TSWAN







