//==============================================================
// xusetemplate.cpp -- Warning: intentional errors in this file
// Time-stamp: <1999-06-30 14:56:45 tswan>
// To compile:
//   g++ -c template.cpp
//   g++ usetemplate.cpp template.o
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>
#include <string>
#include "template.h"

int main()
{
  TAnyClass<int> int_object(123);
  cout << "int_object    == " << int_object.GetData() << endl;

  TAnyClass<double> double_object(3.41459);
  cout << "double_object == " << double_object.GetData() << endl;

  TAnyClass<string> string_object("String object");
  cout << "string_object == " << string_object.GetData() << endl;

  string s("Dynamic string object");
  TAnyClass<string> *p = MakeObject(s);
  cout << "*p == " << p->GetData() << endl;
  delete p;
  
  return 0;
}
