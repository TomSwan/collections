//==============================================================
// xtemplate.cpp -- Warning: Intentional errors in this file
// Time-stamp: <1999-06-30 15:01:03 tswan>
// To compile:
//   g++ -c template.cpp
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include "template.h"

// A template class member function
//
template <class T>
const T & TAnyClass<T>::GetData() const
{
  return data;
}

// A template function
//
template <class T>
TAnyClass<T> * MakeObject(const T param)
{
  return new TAnyClass<T>(param);
}
