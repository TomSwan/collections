//==============================================================
// extension.cpp -- Detect and add a default filename extension
// Time-stamp: <1999-05-24 09:48:50 tswan>
// To compile:
//   g++ extension.cpp
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>
#include <string.h>   // Need strstr(), strcat()

char filename[128];

int main()
{
  cout << "File name (.txt)? ";
  cin >> filename;
  cout << "Original input     : " << filename << endl;
  if ( !strstr(filename, ".txt") )
    strcat(filename, ".txt");
  cout << "Resulting filename : " << filename << endl;
  return 0;
}
