//==============================================================
// stopwatch.cpp -- Calculate elapsed program-running time
// Time-stamp: <1999-06-02 10:37:39 tswan>
// To compile:
//   g++ stopwatch.cpp
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>
#include <sys/times.h>  // need times() function
#include <time.h>       // need CLOCKS_PER_SEC
#include <math.h>       // need fabs() function

// Function prototypes
clock_t mark_time();
double elapsed_time(clock_t start_time, clock_t end_time);

// Main program
int main()
{
  clock_t start, stop;  // Variables for mark_time() function

  cout << "Press enter to start timing...";
  cin.get();
  start = mark_time();  // Mark starting time
  cout << "Press enter to stop timing...";
  cin.get();
  stop = mark_time();   // Mark stopping time
  cout << "Elapsed_time == " 
       << elapsed_time(start, stop) 
       << " seconds" << endl;
  return 0;
}

// Returns current processor time (mark)
clock_t mark_time()
{
  return times(NULL);
}

// Calculate elapsed time in seconds
double elapsed_time(clock_t start_time, clock_t end_time)
{
  double t = fabs(end_time - start_time);  // Processor elapsed time
  return t / (CLOCKS_PER_SEC / 10000);     // Elapsed time in seconds
}
