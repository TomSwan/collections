//==============================================================
// container.h -- Declares the TObject and TContainer classes
// Time-stamp: <1999-06-16 14:33:11 tswan>
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#ifndef __container_H
#define __container_H         // Prevent multiple #includes

#define DEFAULT_SIZE 100      // Default container capacity

class TObject;                // Incomplete class declaration
typedef TObject * PTObject;   // Pointer to a TObject object
typedef PTObject * PPTObject; // Pointer to a TObject pointer

// Abstract class for items to store in a container
//
class TObject {
public:
  virtual ~TObject() { };
  virtual int Compare(PTObject p) = 0;
  virtual void Display() = 0;
};

// The container class
//
class TContainer {
private:
  int size;            // Capacity of objects array
  int count;           // Number of object in array
  PPTObject objects;   // Array of TObject pointers
protected:
  void Quicksort(int left, int right);
public:
  TContainer(int n = DEFAULT_SIZE);  // Constructor
 ~TContainer();                      // Destructor
  //
  // Inline member functions
  //
  bool IsFull()  { return (count >= size); }
  int GetSize()  { return size; }
  int GetCount() { return count; }
  //
  // Other public member functions
  //
  void PutObject(PTObject pto);
  void ShowAllObjects(const char *msg);
  void Sort();
};

#endif  // __container_H




