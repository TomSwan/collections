//==============================================================
// container.cpp -- Implements the TContainer class
// Time-stamp: <1999-06-16 14:39:44 tswan>
// To compile:
//   g++ -c -DDEBUG container.cpp
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>
#include <stdlib.h>     // Need exit()
#include "container.h"  // Need TContainer

// Constructor 
TContainer::TContainer(int n)
{
  if (n <= 0) n = 1;  // Must have at least one element
  size = n;           // Remember capacity
  count = 0;          // Container is empty
  //
  // Create array of object pointers and set to NULL
  //
  objects = new PTObject[size];
  for (int i = 0; i < size; i++)
    objects[i] = NULL;
}

// Destructor
// Define DEBUG to display trace
TContainer::~TContainer()
{
  for (int i = 0; i < count; i++)
    delete objects[i];  // Delete contained objects
#ifdef DEBUG
  cout << "Deleting container" << endl;
#endif
  delete objects;       // Delete array of TObject pointers
}

// Insert new object into container
void TContainer::PutObject(PTObject pto)
{
  if (IsFull())
  {
    cout << "*** Error: Container is full" << endl;
    exit(1);
  }
  objects[count] = pto;
  count++;
}

// Call Display() for all objects in container
void TContainer::ShowAllObjects(const char *msg)
{
  cout << msg << endl;
  cout << "Number of objects == " << count << endl;
  for (int i = 0; i < count; i++)
    objects[i]->Display();  // Calls virtual function!
  cout << endl << endl;
}

void TContainer::Quicksort(int left, int right)
{
  int i = left;
  int j = right;
  PTObject test = objects[(left + right) / 2];
  PTObject swap;
  do {
    while ( objects[i]->Compare(test) < 0) i++;
    while ( test->Compare(objects[j]) < 0) j--;
    if (i <= j) {
      swap = objects[i];
      objects[i] = objects[j];
      objects[j] = swap;
      i++;
      j--;
    }
  } while (i <= j);
  if (left < j) Quicksort(left, j);
  if (i < right) Quicksort(i, right);
}

// Sort objects in container
void TContainer::Sort()
{
  if (count > 1) Quicksort(0, count - 1);
}

