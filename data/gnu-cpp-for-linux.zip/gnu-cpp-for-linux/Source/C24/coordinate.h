//==============================================================
// coordinate.h -- TCoordinate class for STL container programs
// Time-stamp: <1999-07-15 16:06:44 tswan>
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#ifndef __coordinate_H
#define __coordinate_H   // Prevent multiple #includes

#include <iostream.h>

// A class that stores an (x,y) coordinate value
// and is implemented entirely inline.

class TCoordinate {

private:
  int tc_x, tc_y;     // Private data

public:

  // Constructors
  //
  TCoordinate(): tc_x(0), tc_y(0) { }                      // Default constructor
  TCoordinate(int x, int y): tc_x(x), tc_y(y) { }          // Parameterized constructor
  TCoordinate(const TCoordinate& arg)                      // Copy constructor
    { 
      tc_x = arg.tc_x; 
      tc_y = arg.tc_y; 
    }
  ~TCoordinate() { }                                       // Destructor

  // Overloaded operator functions
  //
  void operator=(const TCoordinate &copy)                  // Assignment
    { 
      if (this == &copy) return; 
      tc_x = copy.tc_x;
      tc_y = copy.tc_y;
    }
  bool operator== (const TCoordinate& arg) const           // Equality
    { 
      return (tc_x == arg.tc_x) && (tc_y == arg.tc_y); 
    }
  bool operator< (const TCoordinate& arg) const            // Less than
    { 
      return (tc_x < arg.tc_x) && (tc_y < arg.tc_y); 
    }

  // Overloaded iostream functions
  inline friend ostream & 
    operator<<(ostream & os, const TCoordinate& q);
  inline friend istream &
    operator>>(istream & is, TCoordinate& q);

  // Other member functions
  //
  void Setxy(int x, int y) { tc_x = x; tc_y = y; }
  int Getx() const { return tc_x; }
  int Gety() const { return tc_y; }
};

// Implement the overloaded << operator friend function
//
inline ostream & 
operator<<(ostream & os, const TCoordinate &t)
{
  os << "x == " << t.tc_x << "; y == " << t.tc_y;
  return os;
}

// Implement the overloaded >> operator friend function
//
inline istream &
operator>>(istream & is, TCoordinate &t)
{
  is >> t.tc_x >> t.tc_y;
  return is;
}

#endif  // __coordinate_H

