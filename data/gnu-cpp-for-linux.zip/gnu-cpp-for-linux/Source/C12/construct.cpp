//==============================================================
// construct.cpp -- Demonstrates ways to construct class objects
// Time-stamp: <1999-03-01 11:15:41 tswan>
// To compile:
//   g++ construct.cpp
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>

// A class that encapsulates data and functions
class TDate {
private:
  int dt_month;
  int dt_day;
  int dt_year;
public:
  TDate();
  TDate(int month, int day, int year);
  void Display();
};

int main()
{
  TDate t1;                         // Requires default constructor
  TDate t2 = TDate(12, 31, 1999);   // Impractical, but allowed
  TDate t3(1, 1, 2000);             // Uses parameterized constructor
  TDate t4( t3 );                   // Makes t4 a copy of t3
  TDate t5 = t4;                    // Copies t4 into t5

  t1.Display();  // Call member function for each object
  t2.Display();
  t3.Display();
  t4.Display();
  t5.Display();

  return 0;
}

// The TDate class default constructor
TDate::TDate()
{
  dt_month = 0;       // Initialize private data members to zero
  dt_day = 0; 
  dt_year = 0;
}

// The TDate class parameterized constructor
TDate::TDate(int month, int day, int year)
{
  dt_month = month;   // Assign values to private data members
  dt_day = day;
  dt_year = year;
}

// The TDate class Display member function
void TDate::Display()
{
  cout << dt_month << "/" << dt_day << "/" << dt_year << endl;
}
