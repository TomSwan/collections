//==============================================================
// newmatrix.cpp -- Creates a dynamic 2-dimensional array
// Time-stamp: <1999-09-09 10:54:43 tswan>
// To compile:
//   g++ newmatrix.cpp
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>
#include <iomanip.h>

#define MAX_ROWS 9
#define MAX_COLS 10

int main()
{
  int rows, cols;  // User selectable matrix size
  int r, c;        // Row and column for-loop indexes

  cout << "Rows (1 ... " << MAX_ROWS << ") ? ";
  cin >> rows;
  cout << "Columns (1 ... " << MAX_COLS << ") ? ";
  cin >> cols;

  rows = rows <? MAX_ROWS;   // Minimum of rows and MAX_ROWS
  cols = cols <? MAX_COLS;   // Minimum of cols and MAX_COLS

  if (rows > 0 && cols > 0) {
    int (* matrix)[cols];          // Declare matrix pointer
    matrix = new int[rows][cols];  // Create the dynamic matrix
      
    // Fill the matrix with integer values
    for (r = 0; r < rows; r++)
      for (c = 0; c < cols; c++)
        matrix[r][c] = (r + 1) * (c + 1);

    // Display matrix in column order
    for (c = 0; c < cols; c++) {
      for (r = 0; r < rows; r++)
        cout << setw(8) << matrix[r][c];
      cout << endl;  // Start new line after each row
    }
    delete[] matrix;   // Notice the brackets!
  }
  return 0;
}

