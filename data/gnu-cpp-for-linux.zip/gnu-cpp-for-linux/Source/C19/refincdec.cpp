//==============================================================
// refincdec.cpp -- Demonstrates reference ++ and -- operators
// Time-stamp: <1999-06-25 10:15:39 tswan>
// To compile:
//   g++ refincdec.cpp
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>

// Sample class for object upon which increment and 
// decrement operations are define. Can be anything
// that defines public Increment() and Decrement()
// functions. The output stream operator is just for
// this demonstration and is not required.
//
class TObject {
private:
  int x;
public:
  TObject(int arg): x(arg) { }
  //  int Getx() const { return x; }
  //  int Putx(int arg) { x = arg; }
  void Increment() { x += 1; }
  void Decrement() { x -= 1; }
  friend ostream & operator<<(ostream & os, const TObject &t) {
    os << t.x;
    return os;
  }
};

// Represents the class that overloads ++ and -- operators
// for an object of type TObject. Only that class name needs
// to be changed to use this class. The overloaded output
// stream operator is for this demonstration only.
//
class TAnyClass {
private:
  TObject object;
  TObject temp;
public:
  TAnyClass(int arg): object(arg), temp(arg) { }
  const TObject & operator++() {     // Prefix ++object
    object.Increment();
    return object;
  }
  const TObject & operator++(int) {  // Postfix object++
    temp = object;
    object.Increment();
    return temp;
  }
  const TObject & operator--() {     // Prefix --object
    object.Decrement();
    return object;
  }
  const TObject & operator--(int) {  // Postfix object++
    temp = object;
    object.Decrement();
    return temp;
  }
  friend ostream & operator<<(ostream & os, const TAnyClass &t) {
    os << t.object;
    return os;
  }
};

int main()
{
  TAnyClass t(100);

  cout << "t == " << t;
  cout << "; ++t == " << ++t << endl;
  cout << "t == " << t;
  cout << "; t++ == " << t++ << endl;
  cout << "t == " << t;
  cout << "; --t == " << --t << endl;
  cout << "t == " << t;
  cout << "; t-- == " << t-- << endl;
  
  return 0;
}
