//==============================================================
// predicate.cpp -- Demonstrate predicate functions
// Time-stamp: <1999-07-12 11:10:45 tswan>
// To compile:
//   g++ predicate.cpp
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>
#include <stdlib.h>    // Need random(), srandom()
#include <time.h>      // Need time()
#include <vector>      // Need vector<>
#include <algorithm>   // Need for_each()

vector<double> v(5);   // Vector object

// Program functions to pass to for_each()
//
void initialize(double & rd);
void show(double &rd);
void multiply(double & rd);

int main()
{
  srandom( time(NULL) );  // Seed random generator
  for_each(v.begin(), v.end(), initialize);
  cout << "Vector before multiply" << endl;
  for_each(v.begin(), v.end(), show);
  for_each(v.begin(), v.end(), multiply);
  cout << endl;
  cout << "Vector after multiplying * 10" << endl;
  for_each(v.begin(), v.end(), show);
  cout << endl;
  return 0;
}

// Set rd to a floating point value between 0 and 1.0
void initialize(double &rd)
{
  rd = ( 1.0 * random() / RAND_MAX);
}

// Display the value of rd
void show(double &rd)
{
  cout << rd << "  ";
}

// Multiply rd by 10
void multiply(double & rd)
{
  rd *= 10;
}
