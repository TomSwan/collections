//==============================================================
// sprintfex.cpp -- Demonstrates the sprintf() function
// Time-stamp: <1999-02-16 11:32:33 tswan>
// To compile:
//   g++ sprintfex.cpp
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>
#include <stdio.h>

#define BUFSIZE 128     // Size of formatting buffer

char buffer[BUFSIZE];   // Holds sprintf() output

// A few sample variables:

int xint = 123;
long xlong = 12345678L;
char xchar = '@';
char *xstring = "This is pretty cool!";
double xdouble = 3.14159;
long double xlongdouble = xdouble * xdouble;

int main()
{
  cout << "Sample printf() statements" << endl;
  cout << "VARIABLE          RESULT" << endl;

  sprintf(buffer, "xint (decimal) == %d", xint);
  cout << buffer << endl;

  sprintf(buffer, "xint (hex)     == %#x", xint);
  cout << buffer << endl;

  sprintf(buffer, "xint (octal)   == %#o", xint);
  cout << buffer << endl;

  sprintf(buffer, "xlong          == %ld", xlong);
  cout << buffer << endl;

  sprintf(buffer, "xchar          == %c", xchar);
  cout << buffer << endl;

  sprintf(buffer, "xstring        == %s", xstring);
  cout << buffer << endl;

  sprintf(buffer, "xdouble        == %lf", xdouble);
  cout << buffer << endl;

  sprintf(buffer, "xlongdouble(1) == %Le", xlongdouble);
  cout << buffer << endl;

  sprintf(buffer, "xlongdouble(2) == %Lf", xlongdouble);  
  cout << buffer << endl;

  return 0;
}
