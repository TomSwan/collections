//==============================================================
// getstring.cpp -- Read strings using cin.get()
// Time-stamp: <1999-09-07 11:02:00 tswan>
// To compile:
//   g++ getstring.cpp
// To run:
//   ./a.out
// Copyright (c) 1999 by Tom Swan. All rights reserved.
//==============================================================

#include <iostream.h>

#define BUFSIZE 128     // Room for a 127-char string

char buffer[BUFSIZE];   // Character buffer
char c;                 // For checking buffer limit

int main()
{
  cout << "Enter a string: ";
  cin.get(buffer, BUFSIZE, '\n');
  if (cin.get(c) && c != '\n') {
    cout << endl << "*** Buffer length exceeded" << endl;
    while (cin.get(c) && c != '\n') { }  // Throw out excess
  }
  cout << "buffer == " << buffer << endl;
  return 0;
}
