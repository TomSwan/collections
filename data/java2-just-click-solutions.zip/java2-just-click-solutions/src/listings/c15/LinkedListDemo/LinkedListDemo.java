//==============================================================
// LinkedListDemo.java - Demonstrate using LinkedList containers
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.List;
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Collections;
import Chart;

class LinkedListDemo {

 static final boolean FORWARD = true;
 static final boolean REVERSE = false;

// Display a LinkedList using a ListIterator
//  in forward or reverse order
 public static void showContainer(List c, boolean forward) {
  Chart achart;
  if (forward) {
   // Show in forward order
   ListIterator I = c.listIterator();
   while (I.hasNext()) {
    achart = (Chart)I.next();
    System.out.println(achart.toString());
   }
  } else {
   // Show in reverse order
   ListIterator I = c.listIterator(c.size());
   while (I.hasPrevious()) {
    achart = (Chart)I.previous();
    System.out.println(achart.toString());
   }
  }
 }

 public static void main(String args[]) {
// Construct the container
  LinkedList charts = new LinkedList();  // Can't specify size
  Chart achart;  // For accessing the container's objects

// Insert some Data objects
  charts.add(new Chart(11013, "Morehead City Hrbr ", 12500));
  charts.add(new Chart(11552, "Neuse River        ", 40000));
  charts.add(new Chart(11428, "Dry Tortugas       ", 30000));
  charts.add(new Chart(11420, "Havana to Tampa Bay", 470940));
  charts.add(new Chart(25641, "Virgin Islands     ", 100000));
  charts.add(new Chart(26341, "Bermuda Islands    ", 50000));

  // Sort the LinkedList container
  Collections.sort(charts);

  // Display head and tail objects
  System.out.println("\nHead object is:");
  achart = (Chart)charts.getFirst();
  System.out.println(achart.toString());
  System.out.println("\nTail object is:");
  achart = (Chart)charts.getLast();
  System.out.println(achart.toString());

  // Show list in forward and reverse order
  System.out.println("\nList in forward order");
  showContainer(charts, FORWARD);
  System.out.println("\nList in reverse order");
  showContainer(charts, REVERSE);
 }
}
