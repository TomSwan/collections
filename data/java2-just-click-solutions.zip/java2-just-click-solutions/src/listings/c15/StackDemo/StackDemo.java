//==============================================================
// StackDemo.java - Demonstrate Stack (extended LinkedList) class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import Stack;
 
class StackDemo {
 public static void main(String args[]) {
  String s;
  try {
   Stack fruitStack = new Stack();
   fruitStack.push("Apples");
   fruitStack.push("Peaches");
   fruitStack.push("Pumpkin");
// Enable following to force an unchecked exception
//   fruitStack.removeFirst();
// Peek at top of stack 
   s = (String)fruitStack.peek();
   System.out.println("\nTop of stack = " + s);  
// Pop all objects from stack
   System.out.println("\nPopping all objects:");
   while (!fruitStack.isEmpty()) {
    s = (String)fruitStack.pop();
    System.out.println(s);
   }
// Enable following to force a checked exception
//   s = (String)fruitStack.pop();
  } catch (StackEmptyException e) {
   System.out.println("*** Error: " + e.getMessage());
  }
 }
}
