//==============================================================
// Stack.java - Stack (extended LinkedList) class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Collection;
import java.util.LinkedList;

class StackEmptyException extends Exception {
 StackEmptyException(String s) { super(s); }
}

public class Stack extends LinkedList {
// Constructors
 public Stack() { super(); }
 public Stack(Collection c) { super(c); }
// Public methods
 public void push(Object o) {
  addLast(o);
 }
 public Object pop() throws StackEmptyException {
  if (size() == 0)
   throw new StackEmptyException("pop on empty stack");
  return removeLast();
 }
 public Object peek() throws StackEmptyException {
  if (size() == 0)
   throw new StackEmptyException("peek on empty stack");
  return getLast();
 }
// Unsupported methods (incomplete -- see text)
 public final Object removeFirst() {
  throw new UnsupportedOperationException();
 } 
 public final void addFirst(Object o) {
  throw new UnsupportedOperationException();
 } 
}
