//==============================================================
// Chart.java - Sample data object for container demonstrations
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

public class Chart implements Comparable {
 public int number;
 public String name;
 public long scale;
 public Chart(int number, String name, long scale) {
  this.number = number;
  this.name = name;
  this.scale = scale;
 }
 public int compareTo(Object o) {
  Chart other = (Chart)o;
  return name.compareTo(other.name);
 }
 public String toString() {
  return number + "  " + name + "  1:" + scale;
 }
}
