//==============================================================
// ArrayListDemo.java - Demonstrate some ArrayList methods
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;  // plural!
import Chart;

class ArrayListDemo {

// Display a List of objects
 public static void showContainer(List c) {
  for (int i = 0; i < c.size(); i++)
   System.out.println(c.get(i).toString());
 }

 public static void main(String args[]) {
// Construct the container
  ArrayList charts = new ArrayList();

// Insert some Data objects
  charts.add(new Chart(11013, "Morehead City Hrbr ", 12500));
  charts.add(new Chart(11552, "Neuse River        ", 40000));
  charts.add(new Chart(11428, "Dry Tortugas       ", 30000));
  charts.add(new Chart(11420, "Havana to Tampa Bay", 470940));
  charts.add(new Chart(25641, "Virgin Islands     ", 100000));
  charts.add(new Chart(26341, "Bermuda Islands    ", 50000));

// Sort and display container
  Collections.sort(charts);  
  showContainer(charts);
 }
}
