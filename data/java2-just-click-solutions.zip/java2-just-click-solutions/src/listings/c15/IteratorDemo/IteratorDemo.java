//==============================================================
// IteratorDemo.java - Demonstrate using Iterators with an ArrayList container
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import Chart;

class IteratorDemo {

// Display a Collection using an Iterator
 public static void showContainer(Collection c) {
  Chart achart;
  Iterator I = c.iterator();  // Get Iterator for Collection
  while (I.hasNext()) {       // Always call hasNext()
   achart = (Chart)I.next();  //  before calling next()
   System.out.println(achart.toString());
  }
 }

 public static void main(String args[]) {
// Construct the container
  ArrayList charts = new ArrayList();

// Insert some Data objects
  charts.add(new Chart(11013, "Morehead City Hrbr ", 12500));
  charts.add(new Chart(11552, "Neuse River        ", 40000));
  charts.add(new Chart(11428, "Dry Tortugas       ", 30000));
  charts.add(new Chart(11420, "Havana to Tampa Bay", 470940));
  charts.add(new Chart(25641, "Virgin Islands     ", 100000));
  charts.add(new Chart(26341, "Bermuda Islands    ", 50000));

  System.out.println("\nCharts shown by an Iterator object");
  showContainer(charts);

  // Erase first object
  Iterator I = charts.iterator();  // Get an Iterator object
  if (I.hasNext()) {               // Always call hasNext() and
   Chart c = (Chart)I.next();      //  next() before 
   I.remove();                     //  calling remove()
  }
  System.out.println("\nAfter removing first object");
  showContainer(charts);

  // Use Iterator to remove all objects
  I = charts.iterator();  // Get a fresh Iterator
  while (I.hasNext()) {
   I.next();    // Don't need to save returned object
   I.remove();  // Removes object last returned by next()
  }
  System.out.println("\nAfter removing all objects");
  System.out.println("Container size = " + charts.size());
 }
}
