//==============================================================
// TClass1.java - stuff package Test Class #1
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

package stuff;
 
public class TClass1 {
 String name;  // Friendly instance variable
 public TClass1(String name) {
  this.name = name;
 }
 public String getName() {
  return name;
 }
}
