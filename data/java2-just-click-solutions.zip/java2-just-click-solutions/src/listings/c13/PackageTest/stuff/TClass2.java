//==============================================================
// TClass2.java - stuff package Test Class #2
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

package stuff;

public class TClass2 {
 public String returnName(TClass1 obj) {
  return obj.name;  // Access friendly variable in TClass1
 }
}
