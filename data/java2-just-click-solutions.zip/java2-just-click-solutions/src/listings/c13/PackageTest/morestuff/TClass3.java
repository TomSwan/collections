//==============================================================
// TClass3.java - morestuff package Test Class #2
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

package morestuff;

public class TClass3 {
 private String name;
 public TClass3(String name) {
  this.name = name;
 }
 public String myName() {
  return name;
 }
}
