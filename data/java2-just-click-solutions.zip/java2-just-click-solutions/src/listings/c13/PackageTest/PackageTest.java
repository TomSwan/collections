//==============================================================
// PackageTest.java - Demonstrates using named packages
// Copyright (c) 1997 by Tom Swan. All rights reserved.
//==============================================================

import stuff.*;
import morestuff.TClass3;

class PackageTest {
 public static void main(String args[]) {
  TClass1 x = new TClass1("Message 1");
  System.out.println("via TClass1: " + x.getName());
  TClass2 y = new TClass2();
  System.out.println("via TClass2: " + y.returnName(x));
  TClass3 z = new TClass3("Message 2");
  System.out.println("via TClass3: " + z.myName());
 }
}
