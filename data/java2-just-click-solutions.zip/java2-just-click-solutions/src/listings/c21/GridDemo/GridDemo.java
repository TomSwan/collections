//==============================================================
// GridDemo.java - Demonstrates GridLayout class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.applet.*;
import java.awt.*;

public class GridDemo extends JApplet {

 public void init() {
  JPanel pane = new JPanel();
  pane.setLayout(new GridLayout(4, 3, 8, 16));
  pane.add(new JButton("    1"));
  pane.add(new JButton("ABC 2"));
  pane.add(new JButton("DEF 3"));
  pane.add(new JButton("GHI 4"));
  pane.add(new JButton("JKL 5"));
  pane.add(new JButton("MNO 6"));
  pane.add(new JButton("PRS 7"));
  pane.add(new JButton("TUV 8"));
  pane.add(new JButton("WXY 9"));
  pane.add(new JButton("  *  "));
  pane.add(new JButton("Opr 0"));
  pane.add(new JButton("  #  "));
  getContentPane().add(pane, BorderLayout.CENTER);
 }
}
