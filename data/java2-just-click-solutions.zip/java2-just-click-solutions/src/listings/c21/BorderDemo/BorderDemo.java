//==============================================================
// BorderDemo.java - Demonstrates BorderLayout class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.applet.*;
import java.awt.*;

public class BorderDemo extends JApplet
{
 public void init() {
  JPanel pane = new JPanel();
  pane.setLayout(new BorderLayout());
  pane.add("North",  new JButton("North"));
  pane.add("South",  new JButton("South"));
  pane.add("East",   new JButton("East"));
  pane.add("West",   new JButton("West"));
  pane.add("Center", new JButton("Center"));
  getContentPane().add(pane, BorderLayout.CENTER);
 }
}
