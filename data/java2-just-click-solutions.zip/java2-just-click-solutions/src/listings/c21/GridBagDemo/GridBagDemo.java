//==============================================================
// GridBagDemo.java - Demonstrates GridBagLayout class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.applet.*;
import java.awt.*;

public class GridBagDemo extends JApplet {

 protected void makeButton(String name, GridBagLayout gridbag, 
  GridBagConstraints c, JPanel pane)
 {
  JButton button = new JButton(name);
  gridbag.setConstraints(button, c);
  pane.add(button);
 }

 // Initialize applet and GUI buttons
 public void init() {
  JPanel pane = new JPanel();  // Create content pane
  // Create GridBagLayout and Constraints objects
  GridBagLayout gridbag = new GridBagLayout();
  GridBagConstraints c = new GridBagConstraints();
  pane.setLayout(gridbag);  // Tell pane to use gridbag layout

  // Create four "normal" buttons on the top row
  c.fill = GridBagConstraints.NONE;
  c.weightx = 1.0;
  makeButton("Button 1", gridbag, c, pane);
  makeButton("Button 2", gridbag, c, pane);
  makeButton("Button 3", gridbag, c, pane);
  c.gridwidth = GridBagConstraints.REMAINDER; 
  makeButton("Button 4", gridbag, c, pane);

  // Create a long button filling entire row
  c.fill = GridBagConstraints.BOTH;
  c.weightx = 0.0;
  makeButton("Button 5", gridbag, c, pane);

  // Create two buttons that fill the row
  c.gridwidth = GridBagConstraints.RELATIVE; 
  makeButton("Button 6", gridbag, c, pane);
  c.gridwidth = GridBagConstraints.REMAINDER;
  makeButton("Button 7", gridbag, c, pane);

  // Create a vertical button
  c.gridwidth = 1;
  c.gridheight = 2;
  c.weighty = 1.0;
  makeButton("Button 8", gridbag, c, pane);
  c.weighty = 0.0;

  // Create buttons to right of vertical Button 8
  c.gridwidth = GridBagConstraints.REMAINDER; 
  c.gridheight = 1;
  makeButton("Button 9", gridbag, c, pane);
  makeButton("Button 10", gridbag, c, pane);

  // Add content pane to applet top-level container
  getContentPane().add(pane, BorderLayout.CENTER);
  setSize(325, 250);
 }
}
