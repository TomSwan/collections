//==============================================================
// FlowDemo.java - Demonstrates FlowLayout class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.applet.*;
import java.awt.*;

public class FlowDemo extends JApplet {
 int alignment;  // Current FlowLayout alignment

 public void init() {
  JPanel pane = new JPanel();
  alignment = FlowLayout.LEFT;
// alignment = FlowLayout.CENTER;
// alignment = FlowLayout.RIGHT;
  pane.setLayout(new FlowLayout(alignment));
  pane.add(new JButton("Button1"));
  pane.add(new JButton("Button2"));
  pane.add(new JButton("Button3"));
  pane.add(new JButton("Button4"));
  pane.add(new JButton("Button5"));
  getContentPane().add(pane, BorderLayout.CENTER);
 }
}
