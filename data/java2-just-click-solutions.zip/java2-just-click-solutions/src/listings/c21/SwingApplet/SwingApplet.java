//==============================================================
// SwingApplet.java - Simple Swing applet
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;

public class SwingApplet extends JApplet {
 public void init() {
  JLabel label = 
   new JLabel("Simple Java 2 Swing Applet", JLabel.CENTER);
  label.setBorder(BorderFactory.createLineBorder(Color.black));
  getContentPane().add(label, BorderLayout.CENTER);
 }
}
