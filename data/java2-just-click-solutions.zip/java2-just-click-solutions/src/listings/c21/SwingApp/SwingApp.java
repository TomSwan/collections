//==============================================================
// SwingApp.java - Simple Swing application
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SwingApp {

// Create application component pane as a JPanel container
 public static JPanel createPane() {
  JPanel pane = new JPanel();
  JLabel label = new JLabel("Simple Swing Application");
  pane.setBorder(
   BorderFactory.createEmptyBorder(30, 30, 50, 75));
  pane.add(label);
  return pane;
 }

 public static void main(String[] args) {
  // Use system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getCrossPlatformLookAndFeelClassName());
  } catch (Exception e) { }

  // Create the top-level frame and its components
  JFrame frame = new JFrame("Simple Swing Application");
  JPanel components = createPane();  // Create components pane
  frame.getContentPane().add(components, BorderLayout.CENTER);

  // End program when window closes
  frame.addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  // Engage layout manager and display window
  frame.pack();
  frame.setVisible(true);
 }
}
