//==============================================================
// BoxDemo.java - Demonstrates BoxLayout class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.applet.*;
import java.awt.*;

public class BoxDemo extends JApplet
{
 // Add new button to pane, with center alignment
 protected void addButton(String label, JPanel pane) {
  JButton button = new JButton(label);
  button.setAlignmentX(Component.CENTER_ALIGNMENT);
  pane.add(button);
 }

 public void init() {
  JPanel pane = new JPanel();
  pane.setLayout(new BoxLayout(pane, BoxLayout.Y_AXIS));
  addButton("Small", pane);
  addButton("tiny", pane);
  addButton("Really Big Button", pane);
  addButton("Bottom Button", pane);
  getContentPane().add(pane, BorderLayout.CENTER);
 }
}
