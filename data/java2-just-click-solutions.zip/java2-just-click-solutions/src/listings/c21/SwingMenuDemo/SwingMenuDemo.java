//==============================================================
// SwingMenuDemo.java - Demonstrate Swing pulldown menus
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SwingMenuDemo extends JFrame {

// Constructor does all the setup work
 public SwingMenuDemo() {
  JMenuBar menuBar;    // Menu bar (contains all menus)
  JMenu menu;          // Pulldown menus
  JMenuItem menuItem;  // Items inside pulldown menus

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  // Create the menu bar, menu, and menu item
  menuBar = new JMenuBar();
  setJMenuBar(menuBar);
  menu = new JMenu("Demo");
  menuBar.add(menu);
  menuItem = new JMenuItem("Exit");
  menu.add(menuItem);

  // Attach listener for the menu item
  menuItem.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    System.exit(0);
   }
  });
 }

 // Because SwingMenuDemo is a JFrame, main() is much simpler!
 public static void main(String[] args) {
  SwingMenuDemo app = new SwingMenuDemo();
  app.setTitle("Swing Menu Demo");
  app.setSize(400, 300);
  app.show();
 }
}
