//==============================================================
// ReadLine.java - Prompt user to enter a string
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.*;

public class ReadLine {

 // Input a string
 public static String readLine()
  throws IOException {
  BufferedReader br = 
   new BufferedReader(new InputStreamReader(System.in));
  return br.readLine();
 }

 // Prompt for and input a string
 public static String readLine(String prompt)
  throws IOException {
  System.out.print(prompt);
  return readLine();
 }

 // Main program
 public static void main(String args[])
  throws IOException {
  System.out.println("Enter strings when prompted.");
  System.out.print("Enter your first name: ");
  String s1 = readLine();
  String s2 = readLine("Enter your last name: ");
  System.out.println("Your name: " + s1 + " " + s2);
 }
}
