//==============================================================
// FileInfo.java - Gets information about any file
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.*;
import java.util.Date;

public class FileInfo {

 // Input a string
 public static String readLine()
  throws IOException {
  BufferedReader br = 
   new BufferedReader(new InputStreamReader(System.in));
  return br.readLine();
 }

 // Prompt for and input a string
 public static String readLine(String prompt)
  throws IOException {
  System.out.print(prompt);
  return readLine();
 }

 // Construct File object for named file
 public static File getFileForFilename(String filename)
  throws IOException {
  File fi = new File(filename);
  // Do not move the following statements;
  // order is critical
  if (!fi.exists())
   throw new IOException("File not found");
  if (!fi.isFile())
   throw new IOException("Not a file");
  return fi;
 }

 // Show a labeled string
 public static void showLabel(String label, String s) {
  System.out.print(label);
  System.out.println(s);
 }

 // Display information about file fi
 public static void showInformation(File fi) {
  showLabel("Path     = ", fi.getPath());
  showLabel("Filename = ", fi.getName());
  showLabel("Length   = ",
   new Long(fi.length()).toString());
  showLabel("Readable = ", 
   new Boolean(fi.canRead()).toString());
  showLabel("Writable = ", 
   new Boolean(fi.canWrite()).toString());
  showLabel("Modified = ",
   new Date(fi.lastModified()).toString());
 }

 // Main program method
 public static void main(String args[]) {
  String filename;
  try {
   // Get pathname from command line or prompt user
   if (args.length > 0)
    filename = args[0];
   else
    filename = readLine("File name? ");
   File fi = getFileForFilename(filename);
   showInformation(fi);
  } catch (IOException e) {            // Trap exception
   System.err.println(e.toString());   // Display error
  }
 }
}
