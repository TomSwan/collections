//==============================================================
// ReadData.java - Reads typed data from a file
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.*;

public class ReadData {

 // Main program method
 public static void main(String args[]) {
  // Instance variables
  int dataSize;
  double data[];
  try {
   // Create file objects
   FileInputStream fin = new FileInputStream("Data.bin");
   BufferedInputStream bin = new BufferedInputStream(fin);
   DataInputStream din = new DataInputStream(bin);
   // Read data from file in this order:
   // 1. number of data elements
   // 2. elements
   dataSize = din.readInt();     // Get number of elements
   data = new double[dataSize];  // Create array for data
   // Read elements into array
   for (int i = 0; i < dataSize; i++) {
    data[i] = din.readDouble();  // Read each element
   }
   fin.close();
   // Display results:
   System.out.println("\n" + dataSize + " data elements:\n");
   for (int i = 0; i < dataSize; i++) {
    System.out.println("data[" + i + "] = " + data[i]);
   }
  } catch (EOFException eof) {         // Trap EOF exception
   System.err.println("File damaged or in wrong format");
  } catch (IOException e) {            // Trap exception
   System.err.println(e.toString());   // Display error
  }
 }
}
