//==============================================================
// WriteData.java - Writes typed data to a file
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.*;
import java.util.Random;

public class WriteData {

 // Main program method
 public static void main(String args[]) {
  // Instance variables
  int dataSize = 10;
  Random gen = new Random();
  try {
   // Create file objects
   FileOutputStream fout = new FileOutputStream("Data.bin");
   BufferedOutputStream bout = new BufferedOutputStream(fout);
   DataOutputStream dout = new DataOutputStream(bout);
   // Write data to file in this order:
   // 1. number of data elements
   // 2. elements
   dout.writeInt(dataSize);
   for (int i = 0; i < dataSize; i++) {
    dout.writeDouble(gen.nextDouble());
   }
   dout.flush();
   fout.close();
   System.out.println(dout.size() + " bytes written");
  } catch (IOException e) {            // Trap exception
   System.err.println(e.toString());   // Display error
  }
 }
}
