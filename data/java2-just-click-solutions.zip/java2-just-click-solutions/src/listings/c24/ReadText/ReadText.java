//==============================================================
// ReadText.java - Reads a text file using typed input
// Copyright (c) 1997 by Tom Swan. All rights reserved.
//==============================================================

import java.io.*;

public class ReadText {

 // Input a string
 public static String readLine()
  throws IOException {
  BufferedReader br = 
   new BufferedReader(new InputStreamReader(System.in));
  return br.readLine();
 }

 // Prompt for and input a string
 public static String readLine(String prompt)
  throws IOException {
  System.out.print(prompt);
  return readLine();
 }

 // Construct File object for named file
 public static File getFileForFilename(String filename)
  throws IOException {
  File fi = new File(filename);
  // Do not move the following statements;
  // order is critical
  if (!fi.exists())
   throw new IOException(fi.getName() + " not found");
  if (!fi.isFile())
   throw new IOException(fi.getName() + " is not a file");
  return fi;
 }
 
 // Main program method
 public static void main(String args[]) {
  String filename;
  try {
   // Get pathname from command line or prompt user
   if (args.length > 0)
    filename = args[0];
   else
    filename = readLine("Read what text file? ");
   File fi = getFileForFilename(filename);
   FileInputStream fin = new FileInputStream(fi);
   BufferedReader bin = 
    new BufferedReader(new InputStreamReader(fin));
   String line = bin.readLine();  // Read first line
   while (line != null) {         // Loop until end of file
    System.out.println(line);     // Print current line
    line = bin.readLine();        // Read next line
   }
  } catch (IOException e) {            // Trap exception
   System.err.println(e.toString());   // Display error
  }
 }
}
