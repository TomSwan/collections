//==============================================================
// WriteText.java - Write lines of text to a file
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.*;

public class WriteText {

 static String[] text = {
  "This is a line of text",
  "This is the second line",
  "End of text" };

 // Main program method
 public static void main(String args[]) {
  try {
   // Create output file object
   BufferedWriter tout = 
    new BufferedWriter(new FileWriter("Data.txt"));
   for (int i = 0; i < text.length; i++) {
    tout.write(text[i]);
    tout.newLine();
   }
   tout.flush();
   tout.close();
   System.out.println("File created");
  } catch (IOException e) {            // Trap exception
   System.err.println(e.toString());   // Display error
  }
 }
}
