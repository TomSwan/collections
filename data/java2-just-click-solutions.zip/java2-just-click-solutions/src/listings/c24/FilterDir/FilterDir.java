//==============================================================
// FilterDir.java - Demonstrates filename filters
// Copyright (c) 2001by Tom Swan. All rights reserved.
//==============================================================

import java.io.*;

// File filter class
class FilterClass implements FilenameFilter {
 public boolean accept(File dir, String name) {
  File f = new File(dir, name);
  if (f.isDirectory())
   return true;
  else
   return false;
 }
}

public class FilterDir {

 // Input a string
 public static String readLine()
  throws IOException {
  BufferedReader br = 
   new BufferedReader(new InputStreamReader(System.in));
  return br.readLine();
 }

 // Prompt for and input a string
 public static String readLine(String prompt)
  throws IOException {
  System.out.print(prompt);
  return readLine();
 }

 // Construct File object for directory path
 public static File getFileForPath(String path)
  throws IOException {
  File dir = new File(path);
  if (!dir.isDirectory())
   throw new IOException("Not a directory");
  return dir;
 }

 // Main program method
 public static void main(String args[]) {
  String path;
  try {
   // Get pathname from command line or prompt user
   if (args.length > 0)
    path = args[0];
   else
    path = readLine("Path name? ");
   File dir = getFileForPath(path);
   String[] filenames = dir.list(new FilterClass());
   for (int i = 0; i < filenames.length; i++)
    System.out.println("<DIR> " + filenames[i]);
  } catch (IOException e) {            // Trap exception
   System.err.println(e.toString());   // Display error
  }
 }
}
