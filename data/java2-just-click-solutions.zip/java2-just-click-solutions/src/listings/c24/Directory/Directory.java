//==============================================================
// Directory.java - Demonstrates the File class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.*;

public class Directory {

 // Input a string
 public static String readLine()
  throws IOException {
  BufferedReader br = 
   new BufferedReader(new InputStreamReader(System.in));
  return br.readLine();
 }

 // Prompt for and input a string
 public static String readLine(String prompt)
  throws IOException {
  System.out.print(prompt);
  return readLine();
 }

 // Construct File object for directory path
 public static File getFileForPath(String path)
  throws IOException {
  File dir = new File(path);
  if (!dir.isDirectory())
   throw new IOException("Not a directory");
  return dir;
 }

 // Main program method
 public static void main(String args[]) {
  String path;
  try {
   // Get pathname from command line or prompt user
   if (args.length > 0)
    path = args[0];
   else
    path = readLine("Path name? ");
  // List directory
   File dir = getFileForPath(path);
   String[] filenames = dir.list();
   for (int i = 0; i < filenames.length; i++)
    System.out.println(filenames[i]);
  } catch (IOException e) {            // Trap exception
   System.err.println(e.toString());   // Display error
  }
 }
}
