//==============================================================
// ReadRandom.java - Reads typed data using random access
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.*;

public class ReadRandom {

 public static String readLine()
  throws IOException {
  BufferedReader br = 
   new BufferedReader(new InputStreamReader(System.in));
  return br.readLine();
 }

 // Prompt user for record number
 public static int getRecordNumber()
  throws IOException, NumberFormatException {
   System.out.print("Record number (-1 to quit)? ");
   return Integer.parseInt(readLine());
 }

 // Main program method
 public static void main(String args[]) {
  // Instance variables
  int dataSize;         // Number of elements in file
  int rn;               // Record number
  double value;         // Value of requested record
  int sizeOfInt = 4;    // Size of int variable
  int sizeOfDouble = 8; // Size of double variable  
  boolean wantsToQuit = false;
  try {
   // Create file objects
   File fi = new File("Data.bin");
   RandomAccessFile rin = new RandomAccessFile(fi, "r");
   dataSize = rin.readInt();     // Get number of elements
   // Prompt user for element to read
   System.out.println("\nFile has " + 
    dataSize + " elements\n");
   while (!wantsToQuit) {
    rn = getRecordNumber();
    wantsToQuit = (rn == -1);
    if (!wantsToQuit) {
     // Seek to requested record
     rin.seek(sizeOfInt + (rn * sizeOfDouble));
     // Read and display value
     value = rin.readDouble();
     System.out.println("Record " + rn + " = " + value);
    }
   }
  } catch (IOException e) {            // Trap exception
   System.err.println(e.toString());   // Display error
  }
 }
}
