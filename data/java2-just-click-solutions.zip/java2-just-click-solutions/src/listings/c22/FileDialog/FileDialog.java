//==============================================================
// FileDialog.java - Demonstrate file-open and file-save dialogs
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FileDialog extends JFrame {

 private JFileChooser fDialog;
 JFrame frame;  // Reference to this frame object

// Constructor does all the setup work
 public FileDialog() {

  frame = this;  // So action listeners can find it

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  // Construct the file chooser dialog object
  fDialog = new JFileChooser();

  // Open button displays File:Open dialog
  JButton openButton = new JButton("Open File Dialog");
  openButton.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    String msg;
    int result = fDialog.showOpenDialog(frame);
    if (result == JFileChooser.APPROVE_OPTION) {
     String fname = fDialog.getName(fDialog.getSelectedFile());
     frame.setTitle(fname);
     msg = "File Open Approved";
    } else 
     msg = "File Open Cancelled";
    JOptionPane.showMessageDialog(frame, msg);
   }
  });

  // Save button displays File:Save dialog
  JButton saveButton = new JButton("Save File Dialog");
  saveButton.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    String msg;
    int result = fDialog.showSaveDialog(frame);
    if (result == JFileChooser.APPROVE_OPTION) {
     String fname = fDialog.getName(fDialog.getSelectedFile());
     frame.setTitle(fname);
     msg = "File Save Approved";
    } else 
     msg = "File Save Cancelled";
    JOptionPane.showMessageDialog(frame, msg);
   }
  });

  // Add buttons to the frame's content pane
  Container content = getContentPane();
  content.setLayout(new GridLayout(2, 1, 2, 2));
  content.add(openButton);
  content.add(saveButton);
 }

 public static void main(String[] args) {
  FileDialog app = new FileDialog();
  app.setTitle("File Dialog Demonstration");
  app.setSize(320, 240);
  app.show();
 }
}
