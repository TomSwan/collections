//==============================================================
// ComboDemo.java - Demonstrate JComboBox objects
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class ComboDemo extends JFrame {

 private JFrame frame;  // Refers to this JFrame window
 private JLabel label;  // Shows current selection

// Constructor does all the setup work
 public ComboDemo() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  frame = this;  // So event handler can find our window
  label = new JLabel("Select a month");

  String[] items = {
   "January", "February", "March", "April", "May",
   "June", "July", "August", "September", "October",
   "November", "December"
  };
  JComboBox months = new JComboBox(items);
  months.setSelectedIndex(0);
  months.setEditable(true);
  months.addActionListener(
   new ActionListener() {
    public void actionPerformed(ActionEvent e) {
     JComboBox box = (JComboBox)e.getSource();
     String s = (String)box.getSelectedItem();
     label.setText("Selection: " + s);
    }
   }
  );

  JPanel pane = new JPanel();
  pane.setLayout(new BoxLayout(pane, BoxLayout.Y_AXIS));
  pane.setBorder(
   BorderFactory.createEmptyBorder(20, 20, 20, 20));
  pane.add(label);
  pane.add(months);

  getContentPane().add(pane, BorderLayout.CENTER);
 }

 public static void main(String[] args) {
  ComboDemo app = new ComboDemo();
  app.setTitle("Combo Box Demonstration");
  app.setSize(320, 240);
  app.show();
 }
}
