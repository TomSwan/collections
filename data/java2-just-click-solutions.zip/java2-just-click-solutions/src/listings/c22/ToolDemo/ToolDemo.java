//==============================================================
// ToolDemo.java - Demonstrate toolbars and multiple Action commands
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ToolDemo extends JFrame {

 // The popup menu object
 protected JPopupMenu popupMenu;

 // the toolbar object
 protected JToolBar toolbar;

 // Each Action object responds to a toolbar or menu selection
 Action openAction;
 Action saveAction;
 Action closeAction;
 Action exitAction;

 // Inner class pops up the menu when the proper mouse
 // click or release is detected for the current look-and-feel
 class PopupHandler extends MouseAdapter {
  public void mousePressed(MouseEvent e) {
   if (e.isPopupTrigger())
    popupMenu.show(e.getComponent(), e.getX(), e.getY());
  }
  public void mouseReleased(MouseEvent e) {
   if (e.isPopupTrigger())
    popupMenu.show(e.getComponent(), e.getX(), e.getY());
  }
 } 

 // Create the Action objects, one for each command in 
 // the toolbar and popup menu
 protected void createActionObjects() {
  ImageIcon icon;  // For loading the toolbar and menu icons

  // Create the Open command Action handler
  icon = new ImageIcon("openicon.gif");
  openAction = new AbstractAction("Open", icon) {
   public void actionPerformed(ActionEvent e) {
    // ... do Open command
   }
  };

  // Create the Save command Action handler
  icon = new ImageIcon("saveicon.gif");
  saveAction = new AbstractAction("Save", icon) {
   public void actionPerformed(ActionEvent e) {
    // ... do Save command
   }
  };

  // Create the Close command Action handler
  icon = new ImageIcon("closeicon.gif");
  closeAction = new AbstractAction("Close", icon) {
   public void actionPerformed(ActionEvent e) {
    // ... do Close command
   }
  };

  // Create the Exit command Action handler
  icon = new ImageIcon("exiticon.gif");
  exitAction = new AbstractAction("Exit", icon) {
   public void actionPerformed(ActionEvent e) {
    System.exit(0);
   }
  };
 }

 // Create the popup menu and its commands
 // Assumes all Action objects are initialized
 protected void createPopupMenu() {
  popupMenu = new JPopupMenu();
  popupMenu.add(openAction);
  popupMenu.add(saveAction);
  popupMenu.add(closeAction);
  popupMenu.addSeparator();
  popupMenu.add(exitAction);
 }

 // Create the toolbar
 // Assumes all Action objects are initialized
 protected void createToolbar() {
  toolbar = new JToolBar();
  toolbar.add(openAction);
  toolbar.add(saveAction);
  toolbar.add(closeAction);
  toolbar.addSeparator();
  toolbar.add(exitAction);
 }

 // Constructor
 public ToolDemo() {

  // Select local system look and feel
  // One of the following two choices produces the best
  // looking toolbars
  try {
   UIManager.setLookAndFeel(
   "com.sun.java.swing.plaf.motif.MotifLookAndFeel");
//   "javax.swing.plaf.metal.MetalLookAndFeel");
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  createActionObjects();
  createPopupMenu();
  createToolbar();

  // Register frame listener so menu pops on the
  // proper mouse click depending on the look and feel
  addMouseListener(new PopupHandler());

  Container content = getContentPane();
  // BorderLayout is required for a floating toolbar
  content.setLayout(new BorderLayout());
  content.add(toolbar, BorderLayout.NORTH);
  toolbar.setFloatable(true);
  content.add(new JLabel("Click inside the window"));
 }

 public static void main(String[] args) {
  ToolDemo app = new ToolDemo();
  app.setTitle("Tool bar and Action demo");
  app.setSize(320, 240);
  app.show();
 }
}
