//==============================================================
// ToggleDemo.java - Demonstrate a two-state toggle button
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class ToggleDemo extends JFrame {

  ImageIcon bulbOnIcon;
  ImageIcon bulbOffIcon;
  JToggleButton onOffButton;

// Constructor does all the setup work
 public ToggleDemo() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  bulbOnIcon = new ImageIcon("bulbon.gif");
  bulbOffIcon = new ImageIcon("bulboff.gif");
  onOffButton = new JToggleButton("Off", bulbOffIcon);
  onOffButton.addChangeListener(new ChangeListener() {
   public void stateChanged(ChangeEvent e) {
    if (onOffButton.isSelected()) {
     onOffButton.setIcon(bulbOnIcon);
     onOffButton.setText("On");
    } else {
     onOffButton.setIcon(bulbOffIcon);
     onOffButton.setText("Off");
    }
   }
  });

  Container content = getContentPane();
  content.setLayout(new FlowLayout());
  content.add(onOffButton);
 }

 public static void main(String[] args) {
  ToggleDemo app = new ToggleDemo();
  app.setTitle("Toggle Button Demonstration");
  app.setSize(320, 120);
  app.show();
 }
}
