//==============================================================
// TextDemo.java - Demonstrate JTextArea
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class TextDemo extends JFrame {

// Constructor does all the setup work
 public TextDemo() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  // Use inner panel for a neat appearance
  JPanel pane = new JPanel();

  // Create text area object
  JTextArea theText = new JTextArea();
  theText.setFont(new Font("Courier", Font.PLAIN, 12));
  theText.setLineWrap(false);

  // Add a scroller to the text area object
  JScrollPane scroller = new JScrollPane(theText);
  scroller.setPreferredSize(new Dimension(300, 150));
  scroller.setVerticalScrollBarPolicy(
   JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

  // Create a label for the text area object
  String s = "<html>"
   + "<font size=+1><b>Text area:</b></font>"
   + "</html>";
  JLabel inputLabel = new JLabel(s);
  inputLabel.setLabelFor(theText);
  inputLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

  // Add all components to the content pane
  pane.add(inputLabel);
  pane.add(scroller);
  getContentPane().add(pane);
  setResizable(false);
 }

 public static void main(String[] args) {
  TextDemo app = new TextDemo();
  app.setTitle("Text Area Demonstration");
  app.setSize(320, 240);
  app.show();
 }
}
