//==============================================================
// PopupDemo.java - Demonstrate popup menus
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PopupDemo 
 extends JFrame implements ActionListener {

 // This is the popup menu object
 protected JPopupMenu popupMenu;

 // These are the popup menu items
 protected JMenuItem openMenuItem;
 protected JMenuItem saveMenuItem;
 protected JMenuItem closeMenuItem;
 protected JMenuItem exitMenuItem;

 // Inner class pops up the menu when the proper mouse
 // click or release is detected for the current look and feel
 class PopupHandler extends MouseAdapter {
  public void mousePressed(MouseEvent e) {
   if (e.isPopupTrigger())
    popupMenu.show(e.getComponent(), e.getX(), e.getY());
  }
  public void mouseReleased(MouseEvent e) {
   if (e.isPopupTrigger())
    popupMenu.show(e.getComponent(), e.getX(), e.getY());
  }
 } 

 // Create the popup menu and its commands
 private void createPopupMenu() {
  popupMenu = new JPopupMenu();
  openMenuItem = new JMenuItem("Open");
  openMenuItem.addActionListener(this);
  popupMenu.add(openMenuItem);
  saveMenuItem = new JMenuItem("Save");
  saveMenuItem.addActionListener(this);
  popupMenu.add(saveMenuItem);
  closeMenuItem = new JMenuItem("Close");
  closeMenuItem.addActionListener(this);
  popupMenu.add(closeMenuItem);
  popupMenu.addSeparator();
  exitMenuItem = new JMenuItem("Exit");
  exitMenuItem.addActionListener(this);
  popupMenu.add(exitMenuItem);

  // Register frame listener so menu pops on the
  // proper mouse click depending on the look and feel
  addMouseListener(new PopupHandler());
 }

 // Constructor
 public PopupDemo() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  createPopupMenu();
  Container content = getContentPane();
  content.add(new JLabel("Click inside the window"));
 }

 // All popup menu items are registered on this event handler
 public void actionPerformed(ActionEvent e) {
  JMenuItem menuItem = (JMenuItem)e.getSource();
  
  // Show selected command text (just for demonstration)
  JOptionPane.showMessageDialog(this, 
   "Command: " + menuItem.getText());

  // Find out which command was selected
  if (menuItem.equals(openMenuItem)) {
   // ... do open command
  }
  if (menuItem.equals(saveMenuItem)) {
   // ... do save command
  }
  if (menuItem.equals(closeMenuItem)) {
   // ... do close command
  }
  if (menuItem.equals(exitMenuItem)) {
   System.exit(0);  // Only implemented command
  }
 }

 public static void main(String[] args) {
  PopupDemo app = new PopupDemo();
  app.setTitle("Popup Menu Demonstration");
  app.setSize(320, 240);
  app.show();
 }
}
