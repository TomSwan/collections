//==============================================================
// ListDemo.java - Demonstrate JList list objects
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class ListDemo extends JFrame {

 private JFrame frame;  // Refers to this JFrame window
 private JLabel label;  // Shows current selection

// Constructor does all the setup work
 public ListDemo() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  frame = this;  // So event handler can find our window

  String[] items = {
   "Sunday", "Monday", "Tuesday", "Wednesday",
   "Thursday", "Friday", "Saturday"
  };
  JList dayList = new JList(items);
  dayList.setSelectionMode(
   ListSelectionModel.SINGLE_SELECTION);
  dayList.setAlignmentX(Component.CENTER_ALIGNMENT);
  JScrollPane listScroller = new JScrollPane(dayList);

  // Respond to a list selection event
  dayList.addListSelectionListener(
   new ListSelectionListener() {
    public void valueChanged(ListSelectionEvent e) {
     JList list = (JList)e.getSource();
     if (!list.isSelectionEmpty()) {
      int i = list.getSelectedIndex();
      String s = (String)list.getModel().getElementAt(i);
      label.setText("Selection: " + s);
     }
    }
   }
  );

  label = new JLabel("Select a day");
  Container content = getContentPane();
  content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
  content.add(label);
  content.add(listScroller);
 }

 public static void main(String[] args) {
  ListDemo app = new ListDemo();
  app.setTitle("List Demonstration");
  app.setSize(320, 240);
  app.show();
 }
}
