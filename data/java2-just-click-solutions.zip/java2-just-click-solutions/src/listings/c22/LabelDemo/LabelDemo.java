//==============================================================
// LabelDemo.java - Demonstrate icons and html in JLabel objects
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class LabelDemo extends JFrame {

// Constructor does all the setup work
 public LabelDemo() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  // Place components in a pane for better appearance
  JPanel pane = new JPanel();
  pane.setLayout(new GridLayout(3, 1, 2, 2));
  pane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 0));

  // Create a simple label using default text
  JLabel titleLabel = new JLabel("Three little labels");

  // Add an icon image to a label
  ImageIcon mailIcon = new ImageIcon("mailbox.gif");
  JLabel mailLabel = new JLabel(mailIcon, JLabel.LEADING);
  mailLabel.setText("You have mail");

  // Use HTML to format a label's text font and size
  String s = "<html>"
   + "<font size=+2><b><i>Check this out!</i></b></font>"
   + "</html>";
  ImageIcon handIcon = new ImageIcon("righthand.gif");
  JLabel htmlLabel = new JLabel(s, handIcon, JLabel.CENTER);

  // Add components to the pane, and the pane to content layer
  pane.add(titleLabel);
  pane.add(mailLabel);
  pane.add(htmlLabel);
  getContentPane().add(pane);
 }

 public static void main(String[] args) {
  LabelDemo app = new LabelDemo();
  app.setTitle("Label Demonstration");
  app.setSize(320, 240);
  app.show();
 }
}
