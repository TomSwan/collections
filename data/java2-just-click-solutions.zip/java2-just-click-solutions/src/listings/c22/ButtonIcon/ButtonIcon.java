//==============================================================
// ButtonIcon.java - Display icon images in JButton objects
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ButtonIcon extends JFrame {

// Constructor does all the setup work
 public ButtonIcon() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  ImageIcon prevIcon = new ImageIcon("lefthand.gif");
  JButton prevButton = new JButton("Prev", prevIcon);
  prevButton.setToolTipText("Move to the previous page");
  ImageIcon nextIcon = new ImageIcon("righthand.gif");
  JButton nextButton = new JButton("Next", nextIcon);
  nextButton.setToolTipText("Move to the next page");

  Container content = getContentPane();
  content.setLayout(new FlowLayout());
  content.add(prevButton);
  content.add(nextButton);
 }

 public static void main(String[] args) {
  ButtonIcon app = new ButtonIcon();
  app.setTitle("Button Icon Demo");
  app.setSize(320, 120);
  app.show();
 }
}
