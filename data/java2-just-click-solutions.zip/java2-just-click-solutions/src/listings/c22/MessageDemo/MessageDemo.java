//==============================================================
// MessageDemo.java - Demonstrate Swing's message dialogs
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MessageDemo 
 extends JFrame implements ActionListener {

  final int WARNING = JOptionPane.WARNING_MESSAGE;
  final int ERROR = JOptionPane.ERROR_MESSAGE;
  final int PLAIN = JOptionPane.PLAIN_MESSAGE;
  final int INFO = JOptionPane.INFORMATION_MESSAGE;

  JButton defaultButton;
  JButton warningButton;
  JButton errorButton;
  JButton plainButton;
  JButton infoButton;

 public void showMessage(String s, int msgType) {
  if (msgType < 0)
   JOptionPane.showMessageDialog(this, s);
  else
   JOptionPane.showMessageDialog(this, s, "Message", msgType);
 }

// Constructor does all the setup work
 public MessageDemo() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  defaultButton = new JButton("Default");
  warningButton = new JButton("Warning");
  errorButton = new JButton("Error");
  plainButton = new JButton("Plain");
  infoButton = new JButton("Info");
  defaultButton.addActionListener(this);
  warningButton.addActionListener(this);
  errorButton.addActionListener(this);
  plainButton.addActionListener(this);
  infoButton.addActionListener(this);

  Container content = getContentPane();
  content.setLayout(new GridLayout(3, 2, 2, 2));
  content.add(defaultButton);
  content.add(warningButton);
  content.add(errorButton);
  content.add(plainButton);
  content.add(infoButton);
 }

 public void actionPerformed(ActionEvent e) {
  Object source = e.getSource();  // Which button?
  if (source.equals(defaultButton))
   showMessage("Default message dialog", -1);
  else if (source.equals(warningButton)) 
   showMessage("Warning message dialog", WARNING);
  else if (source.equals(errorButton))
   showMessage("Error message dialog", ERROR);
  else if (source.equals(plainButton))
   showMessage("Plain message dialog", PLAIN);
  else if (source.equals(infoButton))
   showMessage("Information message dialog", INFO);
 }

 public static void main(String[] args) {
  MessageDemo app = new MessageDemo();
  app.setTitle("Message Dialog Demo");
  app.setSize(320, 240);
  app.show();
 }
}
