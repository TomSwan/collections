//==============================================================
// ColorDemo.java - Demonstrate the JColorChooser component
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

public class ColorDemo extends JFrame {

 private JColorChooser colorChooser;  // The Color chooser
 private JPanel colorBox;             // Color sample
 private Color selectedColor;         // Selected color

// Constructor does all the setup work
 public ColorDemo() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  // Set current color and sample panel (top)
  selectedColor = Color.white;
  colorBox = new JPanel();
  colorBox.setBackground(selectedColor);
  colorBox.setPreferredSize(new Dimension(150, 100));
  colorBox.setBorder(
   BorderFactory.createLineBorder(Color.black));

  // Create color chooser and change event listener
  colorChooser = new JColorChooser(selectedColor);
  colorChooser.getSelectionModel().addChangeListener(
   new ChangeListener() {
    public void stateChanged(ChangeEvent e) {
     selectedColor = colorChooser.getColor();
     colorBox.setBackground(selectedColor);
    }
   }
  );

  // Add the sample color pane and chooser to the frame
  Container content = getContentPane();
  content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
  content.add(colorBox);
  content.add(colorChooser);
 }

 public static void main(String[] args) {
  ColorDemo app = new ColorDemo();
  app.setTitle("Color Chooser Demonstration");
  app.setSize(450, 400);
  app.show();
 }
}
