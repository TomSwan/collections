//==============================================================
// YesNoDemo.java - Demonstrate confirmation dialogs
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class YesNoDemo extends JFrame {

// Constructor does all the setup work
 public YesNoDemo() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  JButton optionButton = new JButton("Click Me!");
  optionButton.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    int result = 
     JOptionPane.showConfirmDialog(null,
      "Exit this program now?",
      "Please answer",
      JOptionPane.YES_NO_OPTION);
    if (result == JOptionPane.YES_OPTION)
     System.exit(0);
   }   
  });

  Container content = getContentPane();
  content.add(optionButton);
 }

 public static void main(String[] args) {
  YesNoDemo app = new YesNoDemo();
  app.setTitle("Confirm Dialog Demonstration");
  app.setSize(320, 240);
  app.show();
 }
}
