//==============================================================
// Password.java - Demonstrate JTextField and JPasswordField
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Password 
 extends JFrame implements ActionListener {

 JTextField username;
 JPasswordField password;
 JButton logon;

// Constructor does all the setup work
 public Password() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  // Use inner panel for a neat appearance
  JPanel pane = new JPanel();
  pane.setLayout(new GridLayout(3, 2, 2, 2));
  pane.setBorder(
   BorderFactory.createEmptyBorder(10, 10, 10, 0));

  username = new JTextField(16);
  password = new JPasswordField(16);
  logon = new JButton("Logon");
  logon.addActionListener(this);

  // Prevent user from resizing this JFrame
  setResizable(false);

  // Add components to the pane, and the pane to content layer
  pane.add(new JLabel("User name:"));
  pane.add(username);
  pane.add(new JLabel("Password:"));
  pane.add(password);
  pane.add(new JLabel("Click button to logon:"));
  pane.add(logon);
  getContentPane().add(pane);
 }

 public void actionPerformed(ActionEvent e) {
  Object source = e.getSource();  // Which component?
  if (source.equals(logon)) {
   // *** WARNING: SECURITY DANGER
   char[] ptext = password.getPassword();  // ok
   String s = new String(ptext);  // ???
   JOptionPane.showMessageDialog(this, "Password: " + s);
   // Erase password for safety
   for (int i = 0; i < ptext.length; i++)
    ptext[i] = 0;
   // *** END SECURITY DANGER
  }
 }

 public static void main(String[] args) {
  Password app = new Password();
  app.setTitle("Text field and password demo");
  app.setSize(320, 120);
  app.show();
 }
}
