//==============================================================
// IntDemo.java - Demonstrates integer variables
// Copyright (c) 1997 by Tom Swan. All rights reserved.
//==============================================================

class IntDemo {
 public static void main(String args[]) {

  // Values in decimal, hex, and octal
  int decimalCount = 123; // decimal 123
  int hexCount = 0xF89C;  // decimal 63644
  int octalCount = 037;   // decimal 31

  // Display preceding variables
  System.out.println("decimalCount = " + decimalCount);
  System.out.println("hexCount     = " + hexCount);
  System.out.println("octalCount   = " + octalCount);

  // Variables of each integer data type
  byte byteCount = 0x0F;
  short shortCount = 32767;
  int intCount = 99999;
  long bigNumber = 0x7FFFFFFFFFFFFFFFL;  // Note final L

  // Display preceding variables
  System.out.println("byteCount    = " + byteCount);
  System.out.println("shortCount   = " + shortCount);
  System.out.println("intCount     = " + intCount);
  System.out.println("bigNumber    = " + bigNumber);
  }
}
