//==============================================================
// NoComment.java - Demonstrates Java comment styles 
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

/* This paragraph shows that C-style comments
   may extend for
   several lines. */

/** The NoComment class demonstrates comment styles */
/** This and the last line are "Java Documentation Comments" */
class NoComment {
 public static void main(String args[]) {
  // This comment is not displayed
  System.out.println("This string is displayed");
  System.out.println( /* Embedded comment is not displayed */
   "This string is also displayed");
  /* This single-line C-style comment is not displayed */
 }
}
