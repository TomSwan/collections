//==============================================================
// Welcome.java - Welcome to Java 2 programming
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class Welcome {
 public static void main(String args[]) {
  System.out.println("Welcome to Java 2 programming!");
 }
}
