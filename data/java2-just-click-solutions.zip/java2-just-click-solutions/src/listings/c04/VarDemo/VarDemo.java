//==============================================================
// VarDemo.java - Demonstrates variable declarations 
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class VarDemo {
 public static void main(String args[]) {
  int count;   // Declare a variable
  count = 10;  // Assign value to variable
  System.out.println("Count = " + count);
 }
}
