//==============================================================
// SortObjects.java - Sort objects using the Arrays class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Arrays;

class StringClass implements Comparable {
 private String s;
 StringClass(String s) { 
  this.s = s; 
 }
 void ShowString() {
  System.out.println(s);
 }
 public int compareTo(Object other) {
  StringClass sc = (StringClass)other;
  return s.compareTo(sc.s);
 } 
}

class SortObjects {

 // Display an array of StringClass objects
 public static void ShowStrings(StringClass[] a, String msg) {
  System.out.println(msg);
  for (int i = 0; i < a.length; i++)
   a[i].ShowString();
 }  

 // Create, sort, and display an array of StringClass objects
 public static void main(String args[]) {
  StringClass colors[] = {
   new StringClass("rojo"),
   new StringClass("azul"),
   new StringClass("verde"),
   new StringClass("negro"),
   new StringClass("blanco"),
   new StringClass("cafe"),
   new StringClass("gris")
  };
  ShowStrings(colors, "\nBefore sorting");
  Arrays.sort(colors);
  ShowStrings(colors, "\nAfter sorting");  
 }
}
