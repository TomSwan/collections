//==============================================================
// ObjectArray.java - Create an array of class objects
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class StringClass {
 private String s;
 // Constructor
 StringClass(String s) { 
  this.s = s; 
 }
 void ShowString() {
  System.out.println(s);
 }
}

class ObjectArray {
 public static void main(String args[]) {
  // Construct an array of class objects
   StringClass WeekDays[] = {
    new StringClass("Domingo"),
    new StringClass("Lunes"),
    new StringClass("Martes"),
    new StringClass("Miercoles"),
    new StringClass("Jueves"),
    new StringClass("Viernes"),
    new StringClass("Sabado")
   };
  // Call a method for each arrayed object
  System.out.println("Weekdays in Spanish");
  for (int i = 0; i < WeekDays.length; i++)
   WeekDays[i].ShowString();
 }
}
