//==============================================================
// ArraysList.java - Using an array as a List object
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Arrays;
import java.util.List;

class ArraysList {
 public static void main(String args[]) {
  // Create array of strings
  String fruits[] = {
   "apple", "banana", "cherry", "pear"
  };
  // Convert array to a List object
  List fruitList = Arrays.asList(fruits);
  // Call various List methods for the array  
  int size = fruitList.size();
  System.out.println("List size = " + size);
  String s = (String)fruitList.get(2);
  System.out.println("List element #2 = " + s);
  if (fruitList.contains("banana"))
   System.out.println("fruitList contains banana");
 }
}
