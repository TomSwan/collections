//==============================================================
// SortComparator.java - Sort objects using a Comparator
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Arrays;
import java.util.Comparator;

// Class that implements the Comparator interface
class StringCompare implements Comparator {
 public int compare(Object o1, Object o2) {
  String s1 = (String)o1;
  String s2 = (String)o2;
  return s1.compareTo(s2);
 }
}

class SortComparator {
 // Display an array of Strings
 public static void ShowStrings(String[] a, String msg) {
  System.out.println(msg);
  for (int i = 0; i < a.length; i++)
   System.out.println(a[i]);
 }  
 // Create, sort, and display an array of StringClass objects
 public static void main(String args[]) {
  String colors[] = {
   "rojo", "azul", "verde", "negro", "blanco", "cafe", "gris"
  };
  ShowStrings(colors, "\nBefore sorting");
  // Construct the Comparator object
  StringCompare CompareObject = new StringCompare();
  // Sort the array using the Comparator object
  Arrays.sort(colors, CompareObject);
  ShowStrings(colors, "\nAfter sorting");  
 }
}
