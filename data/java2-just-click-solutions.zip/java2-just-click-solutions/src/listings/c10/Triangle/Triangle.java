//==============================================================
// Triangle.java - Triangular (variable-length multidimensional) arrays
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class Triangle {
 public static void main(String args[]) {
  // Create a triangular array
  int triangular[][];
  triangular = new int[8][];
  for (int i = 0; i < triangular.length; i++)
   triangular[i] = new int[i + 1];

  // Assign values at random to the array
  for (int i = 0; i < triangular.length; i++)
   for (int j = 0; j < triangular[i].length; j++)
    triangular[i][j] = (int)(Math.random() * 100);

  // Display the array's contents
  for (int i = 0; i < triangular.length; i++) {
   for (int j = 0; j < triangular[i].length; j++)
    System.out.print(" \t" + triangular[i][j]);
   System.out.println();
  }
 }
}
