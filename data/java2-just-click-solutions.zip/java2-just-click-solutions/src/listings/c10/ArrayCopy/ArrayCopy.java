//==============================================================
// ArrayCopy.java - Demonstrate array copying techniques
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import TestClass;  // Import submodule

class ArrayCopy {
 // Declare the two arrays
 public static int[] apples, oranges;

  // Array copy method #1
 public static void CopyMethod1() {
  System.out.println("\nArray copy method #1");
  oranges = apples;
// oranges[0]++;    // Enable to change test
  TestClass.CompareArrays(apples, oranges);
 }

 // Array copy method #2
 public static void CopyMethod2() {
  System.out.println("\nArray copy method #2");
  oranges = new int[apples.length];
  System.arraycopy(apples, 0, oranges, 0, apples.length);
 oranges[0]++;    // Enable to change test
  TestClass.CompareArrays(apples, oranges);
 }

 // Array copy method #3
 public static void CopyMethod3() {
  System.out.println("\nArray copy method #3");
  oranges = (int[])apples.clone();
// oranges[0]++;    // Enable to change test
  TestClass.CompareArrays(apples, oranges);
 }

 public static void main(String args[]) {
  // Construct and initialize the first array
  apples = new int[8];
  for (int i = 0; i < apples.length; i++)
   apples[i] = (int)(Math.random() * 100);
  // Copy three ways and test each copy
  CopyMethod1();
  CopyMethod2();
  CopyMethod3();
 }
}
