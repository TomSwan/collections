//==============================================================
// TestClass.java - Submodule for ArrayCopy program
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class TestClass {
 public static void CompareArrays(int apples[], int oranges[])
 {
  // Display the array values
  int i;
  System.out.print("apples : ");
  for (i = 0; i < apples.length; i++)
   System.out.print(apples[i] + " \t");
  System.out.print("\noranges: ");
  for (i = 0; i < oranges.length; i++)
   System.out.print(oranges[i] + " \t");
  System.out.println();  // Start new line

  // Test if the array references are the same
  if (apples == oranges)
   System.out.println("Array references are identical");
  else
   System.out.println("Array references are NOT identical");

  // Test if the array contents are the same
  boolean identical = true;
  for (i = 0; i < apples.length; i++)
   if (apples[i] != oranges[i])
    identical = false;
  if (identical)
   System.out.println("Array contents are the same");
  else
   System.out.println("Array contents are NOT the same");
 }
}
