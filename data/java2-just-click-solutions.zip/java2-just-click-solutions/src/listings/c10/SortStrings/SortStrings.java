//==============================================================
// SortStrings.java - Sort strings using the Arrays class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Arrays;

class SortStrings {
 // Display an array of Strings
 public static void ShowStrings(String[] a, String msg) {
  System.out.println(msg);
  for (int i = 0; i < a.length; i++)
   System.out.println(a[i]);
 }  
 // Create, sort, and display an array of StringClass objects
 public static void main(String args[]) {
  String colors[] = {
   "rojo", "azul", "verde", "negro", "blanco", "cafe", "gris"
  };
  ShowStrings(colors, "\nBefore sorting");
  Arrays.sort(colors);
  ShowStrings(colors, "\nAfter sorting");  
 }
}
