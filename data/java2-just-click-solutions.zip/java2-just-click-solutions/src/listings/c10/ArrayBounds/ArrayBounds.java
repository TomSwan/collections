//==============================================================
// ArrayBounds.java - Demonstrate array boundary exception
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class ArrayBounds {
 public static void main(String args[]) {
  int intArray[] = new int[10]; // Create array
  try {
   int q = intArray[5];   // no error
   int p = intArray[11];  // throws exception
  } catch (ArrayIndexOutOfBoundsException e) {
   System.out.println("Array index out of bounds");
  }
 }
}
