//==============================================================
// LabelDemo.java - Demonstrates label, break, and contine
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class LabelDemo  {
 public static void main(String args[]) {
  int i, j;
OuterLoop:
  for (i = 1; i < 100; i++) {
   System.out.println("\nOuter loop # " + i);
InnerLoop:
   for (j = 1; j < 10; j++) {
    if (j % 2 == 0)
     continue InnerLoop;  // Skip even j values
    if (i > 4)
     break OuterLoop;     // Abort if i > 4
    System.out.println("j = " + j);
   }  // end of inner for statement
  }   // end of outer for statement
   System.out.println("Program exiting at OuterLoop:");
 }    // end of main() method
}     // end of class declaration
