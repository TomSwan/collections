//==============================================================
// DoWhileCount.java - Demonstrates do-while statements
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class DoWhileCount {
 public static void main(String args[]) {
  int count = 0;
  do {
   count++;
   System.out.println("Count = " + count);
  } while (count < 10);
 }
}
