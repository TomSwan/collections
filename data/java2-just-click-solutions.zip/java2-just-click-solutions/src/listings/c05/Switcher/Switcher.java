//==============================================================
// Switcher.java - Demonstrates switch statements
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class Switcher {
 public static void main(String args[]) {
  int a = 2;
  switch (a) {
   case 1:
    System.out.println("Case 1");
    break;
   case 2:
    System.out.println("Case 2");
    System.out.println("Final statement in case 2");
    break;
   case 3:
    System.out.println("Case 3");
    break;
   default:
    System.out.println("All other cases");
  }
 }
}
