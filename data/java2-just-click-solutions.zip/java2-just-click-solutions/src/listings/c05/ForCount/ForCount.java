//==============================================================
// ForCount.java - Demonstrates for statements
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class ForCount {
 public static void main(String args[]) {
  int count;
  for (count = 1; count <= 10; count++) {
   System.out.println("Count = " + count);
  }
 }
}
