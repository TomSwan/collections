//==============================================================
// WhileCount.java - Demonstrates while statements
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class WhileCount {
 public static void main(String args[]) {
  int count = 0;
  while (count < 10) {
   count++;
   System.out.println("Count = " + count);
  }
 }
}
