//==============================================================
// BitSetDemo.java - Demonstrates BitSet class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.BitSet;

class BitSetDemo {
 // Display string and value of BitSet object
 public static void show(String s, BitSet obj) {
  System.out.println(s + obj.toString());
 }
 // Main program tests BitSet Boolean logic
 public static void main(String args[]) {
  // Construct two BitSets
  BitSet set1 = new BitSet(16);
  BitSet set2 = new BitSet(16);
  // Set bits 2, 4, and 8 in set 1
  set1.set(2); set1.set(4); set1.set(8);
  // Set all bits in set 2
  for (int i = 0; i < set2.size(); i++)
   set2.set(i);
  // Test Boolean logic and show results
  show("before XOR set1 = ", set1);
  set1.xor(set2);
  show("after XOR set1  = ", set1);
  set1.xor(set2);
  show("after XOR set1  = ", set1);
 }
}
