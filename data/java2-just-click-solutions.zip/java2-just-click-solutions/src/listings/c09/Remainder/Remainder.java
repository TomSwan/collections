//==============================================================
// Remainder.java - Using the Math class IEEERemainder() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class Remainder {
 public static void main(String args[]) {
  double arg1 = 3.14159;
  double arg2 = 2;
  double result = Math.IEEEremainder(arg1, arg2);
  System.out.println(arg1 + " / " + arg2 + " = " + result);
 }
}
