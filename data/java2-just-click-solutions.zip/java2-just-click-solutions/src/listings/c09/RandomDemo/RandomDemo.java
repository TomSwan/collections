//==============================================================
// RandomDemo.java - Using the Math class random() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class RandomDemo {
 public static void main(String args[]) {
  double doubleResult;
  int intResult;
  for (int i = 1; i < 10; i++) {
    doubleResult = Math.random();
    System.out.print(doubleResult + " \t");
    intResult = (int)(doubleResult * 100);
    System.out.println(intResult);
  }
 }
}
