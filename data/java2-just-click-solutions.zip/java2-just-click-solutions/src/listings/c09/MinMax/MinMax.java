//==============================================================
// MinMax.java - Using the Math class min() and max() methods
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class MinMax {
 public static void main(String args[]) {
  long v1 = 99;
  long v2 = v1 * 2;
  System.out.println("v1=" + v1 + " v2=" + v2);
  System.out.println("Maximum value = " + Math.max(v1, v2));
  System.out.println("Minimum value = " + Math.min(v1, v2));
 }
}
