//==============================================================
// CosDemo.java - Demonstrates Math.cos() (and also that 0 != 0.0!!)
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class CosDemo {
 public static void main(String args[]) {
  double fp, result;
  for (fp = -1.0; fp <= 1.0; fp += 0.1) {
   result = Math.cos(fp);
   System.out.println("fp = " + fp + ", cosine = " + result);
  }
 }
}
