//==============================================================
// PowerDemo.java - Using the Math class pow() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class PowerDemo {
 public static void main(String args[]) {
  if (args.length < 2) {
   System.out.println("Enter two values as follows:");
   System.out.println("java PowerDemo 2 8");
  } else {
   try {
    int j = Integer.parseInt(args[0]);
    int k = Integer.parseInt(args[1]);
    System.out.println(j + " ^^ " + k + " = " + Math.pow(j, k));
   }
    catch (NumberFormatException e) {
    System.out.println("Error in argument " + e.getMessage());
   }
  }
 }
}
