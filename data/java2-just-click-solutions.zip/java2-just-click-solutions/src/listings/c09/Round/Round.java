//==============================================================
// Round.java - Using the Math class rounding methods
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class Round {
 public static void main(String args[]) {
  double arg = 3.14159;
  double doubleResult = Math.rint(arg);
  int    intResult    = (int)Math.round(arg);
  long   longResult   = Math.round(arg);
  System.out.println("double rint(arg) = " + doubleResult);
  System.out.println("(int)round(arg)  = " + intResult);
  System.out.println("(long)round(arg) = " + longResult);
 }
}
