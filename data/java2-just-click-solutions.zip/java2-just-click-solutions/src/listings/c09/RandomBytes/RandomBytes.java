//==============================================================
// RandomBytes.java - Using the Random.nextBytes() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Random;

class RandomBytes {
 static int SIZE = 64;    // Number of bytes to generate
 static byte byteArray[]; // The array of bytes

 // Display byte array
 public static void showArray(String label) {
  System.out.println("\n\n" + label);
  for (int i = 0; i < byteArray.length; i++) {
   if (i % 8 == 0) 
    System.out.println();    // Start new row
   else
    System.out.print('\t');  // Start new column
   System.out.print(byteArray[i]);
  }
 }

 public static void main(String args[]) {
  Random generator = new Random();
  byteArray = new byte[SIZE];
  showArray("Before randomizing");
  generator.nextBytes(byteArray);  // Fill array
  showArray("After randomizing");
 }
}
