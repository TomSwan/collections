//==============================================================
// ConvertInt.java - Convert integer to hex, octal, etc
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class ConvertInt {
 public static void main(String args[]) {
  if (args.length < 1)
   System.out.println("ex. java ConvertInt 1234");
  else 
   try {
    int intValue = Integer.parseInt(args[0]);
    System.out.println("Default = " 
     + Integer.toString(intValue));
    System.out.println("Hex = " 
     + Integer.toHexString(intValue));
    System.out.println("Octal = " 
     + Integer.toOctalString(intValue));
    System.out.println("Binary = " 
     + Integer.toBinaryString(intValue));
    System.out.println("base 32 = " 
     + Integer.toString(intValue, 32));
   } catch (NumberFormatException e) {
    System.out.println(
     "Format error in argument " + e.getMessage());
  }
 }
}
