//==============================================================
// RandGen.java - Demonstrates the Random class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Random;

class RandGen {
 public static void main(String args[]) {
  Random generator = new Random();
  int rows, cols;
  StringBuffer buffer;
  for (rows = 1; rows <= 8; rows++) {
   buffer = new StringBuffer(128);
   for (cols = 1; cols <= 3; cols++) {
    buffer.append(generator.nextDouble() + " \t");
//  buffer.append(generator.nextInt() + " \t");
   }
   System.out.println(buffer);
  }
 }
}
