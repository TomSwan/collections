//==============================================================
// ParseFloat.java - Demonstrate parsing strings to float values
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class ParseFloat {
 public static void main(String args[]) {
  if (args.length < 1) 
   System.out.println("ex. java ParseFloat 3.14159");
  else {
   try {
    float f = Float.parseFloat(args[0]);
    System.out.println("Value == " + f);
   } catch (NumberFormatException e) {
    System.out.println("Error in argument " + e.getMessage());
   }
  }
 }
}
