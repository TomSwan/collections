//==============================================================
// CeilFloor.java - Using the Math class ceil() and floor() methods
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class CeilFloor {
 public static void main(String args[]) {
  double d = 10.0;
  while (d < 11.0) {
   System.out.println("d=" + d + " ceil(d)=" + Math.ceil(d) +
    " floor(d)=" + Math.floor(d));
   d += 0.1;
  }
 }
}
