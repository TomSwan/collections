//==============================================================
// BooleanDemo.java - Using the Boolean wrapper class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class BooleanDemo {
 public static void main(String args[]) {
  // Shows that TRUE and FALSE are objects
  Boolean boolObject = new Boolean(true);
  if (boolObject.equals(Boolean.TRUE))
   System.out.println("boolObject is true");
  // But that true and false are native values
  boolean boolValue = true;
  if (boolValue = Boolean.TRUE.booleanValue())
   System.out.println("boolValue is true");
 }
}
