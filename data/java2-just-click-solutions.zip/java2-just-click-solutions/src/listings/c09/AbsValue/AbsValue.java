//==============================================================
// AbsValue.java - Using the Math class abs() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class AbsValue {
 public static void main(String args[]) {
  int v = -100;
  char ch = (char)Math.abs(v);
  System.out.println("char(" + Math.abs(v) + ") = " + ch);
 }
}
