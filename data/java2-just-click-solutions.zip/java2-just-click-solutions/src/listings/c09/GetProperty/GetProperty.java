//==============================================================
// GetProperty.java - Demonstrates Boolean.getBoolean() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class GetProperty {
 static String DEBUGGINGPROP = "Debugging.prop";
 static String NAMEPROP = "Program.name.prop";
 static String NAMEVALUE = "GetProperty";

 public static void main(String args[]) {
  System.setProperty(DEBUGGINGPROP, "true"); // Boolean prop
  System.setProperty(NAMEPROP, NAMEVALUE);   // Other prop

  boolean result;
  String valueStr;

  // Get true or false value of boolean property
  result = Boolean.getBoolean(DEBUGGINGPROP);
  System.out.println(DEBUGGINGPROP + " = " + result);

  // Get value of non-boolean property
  valueStr = System.getProperty(NAMEPROP);
  result = Boolean.getBoolean(NAMEPROP);
  System.out.println(NAMEPROP + " value = " + valueStr);
  System.out.println(NAMEPROP + " result = " + result);
 }
}
