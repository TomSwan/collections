//==============================================================
// RandomSeed.java - Reseeding a Random object
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Random;

class RandomSeed {
 static long SEED = 12345;
 public static void main(String args[]) {
  Random generator = new Random(SEED);
  System.out.println("\nInitial sequence:");
  for (int i = 0; i < 32; i++)
   System.out.print(generator.nextInt(100) + " \t");
  generator.setSeed(SEED);  // Reseed the generator
  System.out.println("\n\nAfter reseeding generator:");
  for (int i = 0; i < 32; i++)
   System.out.print(generator.nextInt(100) + " \t");
 }
}
