//==============================================================
// FontDemo.java - How to use fonts in Java applications
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;

// Window frame class for showing selected font sample
class FontSample extends JFrame {
 Font font;    // Currently shown font
 String text;  // Sample text to display

 // Constructor
 public FontSample() {
  super();
  font = null;
  text = "Abcdefg 1234567890 !@#$%^&*()";
  setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
  setSize(425, 120);
 }

 // Called before showing window
 public void changeFont(Font f) {
  font = f.deriveFont(24.0f);   // Resize to 24 pts
  setTitle(font.getFontName()); // Title = font name
  if (isShowing()) repaint();   // Repaint if already visible
 }

 // Paint sample text using current font in window
 public void paint(Graphics g) {
  Rectangle r = getBounds(null);
  g.setColor(Color.white);  // Erase background to white
  g.fillRect(0, 0, r.width, r.height);
  if (font != null) {
   g.setFont(font);
   g.setColor(Color.black);
   g.drawString(text, 10, r.height / 2);
  }
 }
}

// Main program class
public class FontDemo extends JFrame {
 final protected Font[] fonts;           // Array of fonts
 final protected FontSample fontSample;  // Sample window

// Constructor 
 public FontDemo() {
  super();
  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getSystemLookAndFeelClassName());
  } catch (Exception e) { }
  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  // Create child sample font window
  fontSample = new FontSample();

  // Loading fonts may take a while; tell user
  System.out.print("Loading font names...");

  // Get available fonts in 1pt sizes
  GraphicsEnvironment ge = 
   GraphicsEnvironment.getLocalGraphicsEnvironment();
  fonts = ge.getAllFonts();

  // Create a JComboBox object for listing font names
  JComboBox fontBox = new JComboBox();
  for (int i = 0; i < fonts.length; i++)
   fontBox.addItem(fonts[i].getFontName());
  fontBox.setEditable(false);

  // Respond to item selection
  fontBox.addActionListener(
   new ActionListener() {
    public void actionPerformed(ActionEvent e) {
     JComboBox box = (JComboBox)e.getSource();
     int fontIndex = box.getSelectedIndex();
     fontSample.changeFont(fonts[fontIndex]);
     fontSample.show();
    }
   }
  );
  
  System.out.println("\nSelect font for a sample"); 
  Container content = getContentPane();
  content.setLayout(new FlowLayout());
  content.add(new JLabel("Available fonts"));
  content.add(fontBox);
 }

 public static void main(String[] args) {
  FontDemo app = new FontDemo();
  app.setTitle("Font Demonstration");
  app.setSize(320, 240);
  app.show();
 }
}
