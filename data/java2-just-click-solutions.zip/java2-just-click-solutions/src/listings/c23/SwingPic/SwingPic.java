//==============================================================
// SwingPic.java - Use Swing to load and display a graphics image
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SwingPic extends JFrame {

 // Picture file name
 protected String filename = "AS17-148-22721.jpg";
 protected ImageIcon image;

 // Constructor
 public SwingPic() {

  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getCrossPlatformLookAndFeelClassName());
  } catch (Exception e) { }

  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  // Load image from file
  image = new ImageIcon(filename);
  int height = image.getIconHeight();
  int width = image.getIconWidth();

  // Create a label to hold the image as an icon
  JLabel labeledPic = new JLabel(image, JLabel.CENTER);
  labeledPic.setText(filename);

  // Create a scroller to hold the labeled image
  JScrollPane scroller = new JScrollPane(labeledPic);  
  scroller.setPreferredSize(new Dimension(height, width));

  // Add the scroller to the frame's content layer  
  Container content = getContentPane();
  content.add(scroller);
  setSize(width, height);  // Sets window's initial size
 }

 public static void main(String[] args) {
  SwingPic app = new SwingPic();
  app.setTitle("Swing Picture Demonstration");
  app.show();
 }
}
