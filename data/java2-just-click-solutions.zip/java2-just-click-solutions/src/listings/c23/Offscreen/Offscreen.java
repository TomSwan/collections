//==============================================================
// Offscreen.java - Creates and displays an offscreen image
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.applet.*;
import java.awt.*;
import java.util.Random;

public class Offscreen extends Applet
 implements Runnable {

 // Instance variables
 Thread drawingThread;
 Image offscreenImage;
 Graphics offscreenContext;
 Random gen;
 boolean imageReady = false;
 int imageW, imageH;
 int numOvals = 100;

 // Initialize applet
 public void init() {
  // Size applet window
  imageW = 320;
  imageH = 240;
  resize(imageW, imageH);
  // Construct random number generator
  gen = new Random();
  // Create offscreen image and Graphics context
  offscreenImage = createImage(imageW, imageH);
  offscreenContext = offscreenImage.getGraphics();
 }

 // Create and start drawing thread
 public void start() {
  drawingThread = new Thread(this);
  drawingThread.start();
 }

 // Return positive integer at random between
 // low and high. Assumes low < high and are positive
 public int nextInt(int low, int high) {
  return low + (Math.abs(gen.nextInt()) % (high - low));
 }

 // Create image using separate thread
 public void run() {
  // Paint image background white
  offscreenContext.setColor(getBackground());
  offscreenContext.fillRect(0, 0, imageW, imageH);
  // Create and paint ovals at random
  for (int i = 0; i < numOvals; i++) {
   // Select oval color at random
   Color c = new Color(nextInt(0, 0xffffff));
   offscreenContext.setColor(c);
   // Select oval position
   int x = nextInt(20, imageW - 20);
   int y = nextInt(20, imageH - 20);
   // Calculate oval width and height
   // so it remains inside image boundaries
   int w = nextInt(10, Math.min(imageW - x, x));
   int h = nextInt(10, Math.min(imageH - y, y));
   // Draw oval to offscreen image
   offscreenContext.fillOval(x, y, w, h);
   Thread.yield();
  }
  imageReady = true;
  repaint();
 }

 // Paint window contents
 public void paint(Graphics g) {
  if (imageReady) {
   showStatus("Showing image...");
   g.drawImage(offscreenImage, 0, 0, this);
  } else {
   g.setColor(getBackground());
   g.fillRect(0, 0, imageW, imageH);
   showStatus("Preparing image...");
  }
 }

 // Override inherited update() method
 // to prevent screen flicker
 public void update(Graphics g) {
  paint(g);
 }
}
