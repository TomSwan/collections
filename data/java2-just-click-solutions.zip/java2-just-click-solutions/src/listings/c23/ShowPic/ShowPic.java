//==============================================================
// ShowPic.java - Loads and displays a graphics image
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.applet.*;
import java.awt.*;

public class ShowPic extends Applet
 implements Runnable {

 // Instance variables
 Image pic;             // GIF image producer
 int picID;             // Arbitrary image ID
 MediaTracker tracker;  // Tracks loading of image
 Thread loadingThread;  // Thread for loading image
 String filename = "ksc-01pp-0287.jpg";  // File name

 // Initialize applet
 public void init() {
  // Create MediaTracker object
  tracker = new MediaTracker(this);
  // Start image loading
  pic = getImage(getDocumentBase(), filename);
  picID = 0;
  tracker.addImage(pic, picID);
  // Create thread to monitor image loading
  loadingThread = new Thread(this);
  loadingThread.start();
 }

 // Run loading thread
 // Allows other processes to run while loading
 // the image data
 public void run() {
  try {
   tracker.waitForID(picID);
  } catch (InterruptedException ie) {
   return;
  }
  repaint();  // Cause paint() to draw loaded image
 }

 // Paint window contents
 // Displays loading or error message until
 // image is ready, then shows image
 public void paint(Graphics g) {
  if (tracker.isErrorID(picID))
   g.drawString("Error loading " + filename, 10, 20);
  else if (tracker.checkID(picID))
   g.drawImage(pic, 0, 0, this);
  else
   g.drawString("Loading " + filename, 10, 20);
 }
}
