//==============================================================
// Gradient.java - Display a Color in various shades (gradients)
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Gradient extends JFrame {

// Constructor 
 public Gradient() {
  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getCrossPlatformLookAndFeelClassName());
  } catch (Exception e) { }
  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });
 }

 public void paint(Graphics g) {
  int increment = 40;
  Rectangle r = getBounds(null);
  Color c = new Color(50, 255, 50);
  int x = 0;
  while (x < r.width) {
   g.setColor(c);
   g.fillRect(x, 0, x + increment, r.height);
   c = c.darker();
   x += increment;
  }
 }

 public static void main(String[] args) {
  Gradient app = new Gradient();
  app.setTitle("Gradient Color Demonstration");
  app.setSize(320, 240);
  app.show();
 }
}
