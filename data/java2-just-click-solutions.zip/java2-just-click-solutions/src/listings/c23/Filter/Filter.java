//==============================================================
// Filter.java - Converts color GIF file to gray-scale image
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.applet.*;
import java.awt.*;
import java.awt.image.*;

//==========================================================
// BWFilter (black and white filter) class
//==========================================================

class BWFilter extends RGBImageFilter {

 // Constructor
 public BWFilter() {
  canFilterIndexColorModel = true;
 }

 // Return rgb color converted to shade of gray
 public int filterRGB(int x, int y, int rgb) {
  // Reduce rgb to hue, saturation, brightness elements
  Color c = new Color(rgb);
  float[] hsbvals = Color.RGBtoHSB(c.getRed(), c.getGreen(),
   c.getBlue(), null);
  // Return new color value of same brightness but
  // with hue and saturation set to zero
  return Color.HSBtoRGB(0.0f, 0.0f, hsbvals[2]);
 }
}

//==========================================================
// Applet class
//==========================================================

public class Filter extends Applet
 implements Runnable {

  // Instance variables
 Image pic;             // GIF image producer
 int picID;             // Arbitrary image ID
 MediaTracker tracker;  // Tracks loading of image
 Thread loadingThread;  // Thread for loading image
 String filename = "Clown.gif";  // File name
 boolean imageReady = false;  // Offscreen image flag
 Image bwPic;                 // Offscreen image object

 // Initialize applet
 public void init() {
  // Size applet window
  resize(320, 200);
  // Create MediaTracker object
  tracker = new MediaTracker(this);
  // Start image loading
  pic = getImage(getDocumentBase(), filename);
  picID = 0;
  tracker.addImage(pic, picID);
  // Create thread to monitor image loading
  loadingThread = new Thread(this);
  loadingThread.start();
 }

 // Run loading thread
 // Allows other processes to run while loading
 // the image data
 public void run() {
  try {
   tracker.waitForID(picID);
   if (tracker.checkID(picID, true)) {
    // Create offscreen image using loaded GIF
    // file filtered by our BWFilter class
    ImageProducer picSource = pic.getSource();
    BWFilter bwFilter = new BWFilter();
    bwPic = createImage(new 
     FilteredImageSource(picSource, bwFilter));
    imageReady = true;
   }
  } catch (InterruptedException ie) {
   return;
  }
  repaint();  // Cause paint() to draw loaded image
 }

 // Paint window contents
 // Displays loading or error message until
 // image is ready, then shows image
 public void paint(Graphics g) {
  if (tracker.isErrorID(picID))
   g.drawString("Error loading " + filename, 10, 20);
  else if (tracker.checkID(picID) && imageReady)
   g.drawImage(bwPic, 0, 0, this);  // Show offscreen image
  else
   g.drawString("Loading " + filename, 10, 20);
 }
}
