//==============================================================
// GraphicsApp.java - Demonstrate 2D graphics in an application
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GraphicsApp extends JFrame {

// Constructor 
 public GraphicsApp() {
  // Select local system look and feel
  try {
   UIManager.setLookAndFeel(
    UIManager.getCrossPlatformLookAndFeelClassName());
  } catch (Exception e) { }
  // End program when window closes
  addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });
 }

 public void paint(Graphics g) {
  // Get window size
  Rectangle r = getBounds(null);
  // Paint background yellow
  g.setColor(Color.yellow);
  g.fillRect(0, 0, r.width, r.height);
  // Outline window in black
  g.setColor(Color.black);
  g.drawRect(0, 0, r.width, r.height);
  // Draw grid inside window
  for (int h = 0; h < r.height; h += 10)
   g.drawLine(0, h, r.width, h);
  for (int v = 0; v < r.width; v += 10)
   g.drawLine(v, 0, v, r.height);
  // Draw overlapping round rectangles
  int cx = r.width / 8;
  int cy = r.height / 3;
  int w = (r.width / 4) * 3;
  int h = cy;
  g.setColor(Color.gray);
  g.fillRoundRect(cx - 4, cy - 4, w, h, 10, 10);
  g.setColor(Color.blue);
  g.fillRoundRect(cx + 4, cy + 4, w, h, 10, 10);
  // Draw text inside outer rectangle
  Font f = new Font("TimesRoman", 
   Font.BOLD + Font.ITALIC, 24);
  g.setFont(f);
  g.setColor(Color.orange);
  g.drawString("Java 2 Just Click! Solutions", cx + 25, cy + 36);
  g.drawString("Graphics Demonstration", cx + 35, cy + 66);
 }

 public static void main(String[] args) {
  GraphicsApp app = new GraphicsApp();
  app.setTitle("Graphics Demonstration (application)");
  app.setSize(450, 280);
  app.show();
 }
}
