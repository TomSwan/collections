//==============================================================
// Animation.java - Demonstrates image animation
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.applet.*;
import java.awt.*;

public class Animation extends Applet 
 implements Runnable {

 // Thread for loading and displaying images
 Thread animThread = null;

 private final int NUM_IMAGES = 10; // Number of image files
 private Image images[];            // Array of images
 private int currImage;             // Index of current image
 private int imgWidth  = 0;         // Width of all images
 private int imgHeight = 0;         // Height of all images
 private boolean allLoaded = false; // true = all loaded
 private MediaTracker tracker;      // Tracks image loading
 private int width, height;         // Applet width and height

 // Initialize applet
 public void init() {
  width = 320;
  height = 240;
  resize(width, height);
  // Create MediaTracker object. The string is
  // for creating the image filenames.
  tracker = new MediaTracker(this);
  String strImage;
  // Load all images. Method getImage() returns immediately
  // and all images are NOT actually loaded into memory
  // by this loop.
  images = new Image[NUM_IMAGES];  // Create image array
  for (int i = 1; i <= NUM_IMAGES; i++) {
   strImage = "images/img00" + ((i < 10) ? "0" : "") 
    + i + ".gif";
   images[i-1] = getImage(getDocumentBase(), 
    strImage);
   tracker.addImage(images[i-1], 0);
  }
 }

 // Paint window contents
 public void paint(Graphics g)
 {
  // Draw current image
  if (allLoaded) {
   g.drawImage(images[currImage],
    (width - imgWidth) / 2,
    (height - imgHeight) / 2, null);
  }
 }

 // Create and start animation thread
 public void start() {
  if (animThread == null) {
   animThread = new Thread(this);
   animThread.start();
  }
 }

 // Run image load and display thread
 public void run() {
  // Load images if not already done
  if (!allLoaded) {
   showStatus("Loading images...");
   // Wait for images to be loaded
   // Other processes continue to run normally
   try  {
    tracker.waitForAll();
   }
   catch (InterruptedException e) {
    stop();  // Stop thread if interrupted
    return;  // Abort loading process
   }
   // If all images are not loaded by this point, 
   // something is wrong and we display an error 
   // message.
   if (tracker.isErrorAny()) {
    showStatus("Error loading images!");
    stop();
    return;
   }
   
   // All images are loaded. Set the loaded flag
   // and prepare image size variables
   allLoaded = true;
   imgWidth  = images[0].getWidth(this);
   imgHeight = images[0].getHeight(this);
  }
  
  // Loop endlessly so animation repeats
  // User ends loop by leaving the page or exiting
  // the browser.
  showStatus("Displaying animation");
  while (true) {
   try {
    repaint();
    currImage++;
    if (currImage == NUM_IMAGES)
     currImage = 0;
    Thread.sleep(50);  // Controls animation speed
   }
   catch (InterruptedException e) {
    stop();
   }
  }  // end of while statement
 }  // end of run() method
}
