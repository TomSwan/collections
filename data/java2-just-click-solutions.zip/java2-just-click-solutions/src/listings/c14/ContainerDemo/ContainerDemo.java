//==============================================================
// ContainerDemo.java - Demonstrate using a container class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.ArrayList;

class ContainerDemo {
 public static void main(String args[]) {
  ArrayList myList = new ArrayList(25);
  myList.add(new String("One"));
  myList.add(new String("Two"));
  myList.add("Buckle");
  String s = "My shoe";
  myList.add(s);
  System.out.println("There are " + 
   myList.size() + " strings in myList");
  for (int i = 0; i < myList.size(); i++)
   System.out.println(myList.get(i));
 }
}
