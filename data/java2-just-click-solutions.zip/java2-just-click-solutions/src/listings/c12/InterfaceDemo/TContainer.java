//==============================================================
// TContainer.java - Implementing an interface
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import TContainerInterface;
import java.util.Arrays;

class TContainer implements TContainerInterface {
 int count;          // Number of strings in array
 String strArray[];  // The array of strings

// Constructor (not declared in the interface)
 TContainer(int n) {
  if (n <= 0) n = 1;
  count = 0;
  strArray = new String[n];
 }

// Put an object into the container
 public void PutObject(Object obj)
  throws ContainerFullException {
  if (count >= strArray.length)
   throw new ContainerFullException();
  strArray[count++] = (String)obj;
 }

// Return object n from the container
 public Object GetObject(int n)
  throws NoSuchObjectException {
  if (n < 0 || n >= count)
   throw new NoSuchObjectException();
  return strArray[n];
 }

// Return number of objects in container
 public int GetCount() {
  return count;
 }

// Sort objects in the container  
 public void Sort() {
  if (count > 1)
   Arrays.sort(strArray, 0, count);
 }
}
