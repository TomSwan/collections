//==============================================================
// TContainerInterface.java - Creating an interface
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class ContainerFullException extends Exception { }
class NoSuchObjectException extends Exception { }

public interface TContainerInterface {
 void PutObject(Object obj)
  throws ContainerFullException;
 Object GetObject(int n)
  throws NoSuchObjectException;
 int GetCount();
 void Sort();
}
