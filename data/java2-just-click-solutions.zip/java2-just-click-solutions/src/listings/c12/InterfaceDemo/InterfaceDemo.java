//==============================================================
// InterfaceDemo.java - Demonstrate using an implemented interface
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import TContainerInterface;
import TContainer;

class InterfaceDemo {

// Show objects in container
 public static void ShowAllObjects(
  TContainerInterface C, String label) {
  System.out.println(label);
  try {
   for (int i = 0; i <= C.GetCount() - 1; i++)
    System.out.print(C.GetObject(i) + "  ");
   System.out.println();
  } catch (NoSuchObjectException e) {
   // Should never execute
   System.out.println("\n *** Error in for loop!");
  }
 }

// Main program demonstrates using the container
 public static void main(String args[]) {
  TContainer container = new TContainer(100);
  try {
   container.PutObject("Mexico");
   container.PutObject("Canada");
   container.PutObject("United States");
   container.PutObject("Honduras");
   container.PutObject("Bahamas");
   container.PutObject("England");
   container.PutObject("Germany");
   container.PutObject("France");
   ShowAllObjects(container, "Before sorting");
   container.Sort();
   ShowAllObjects(container, "After sorting");
  } catch (ContainerFullException e) {
   System.out.println("Container overflow error");
  }
 }
}
