//==============================================================
// CloneDemo.java - Implementing the Cloneable interface
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

// A simple string container class
class IntContainer implements Cloneable {
 private int size;  // Size (capacity) of array
 private int intArray[];
 public IntContainer(int n) {
  intArray = new int[n];
  size = n;
 }
 public int getValue(int n) { 
  return intArray[n]; 
 }
 public void putValue(int index, int value) { 
  intArray[index] = value;
 }
 public int size() {
  return size;
 }
/*
// The WRONG way to clone
 public Object clone() throws CloneNotSupportedException {
  return super.clone();  // ???
 }
*/
// The RIGHT way to clone
 public Object clone() throws CloneNotSupportedException {
  IntContainer temp = (IntContainer)super.clone();
  temp.intArray = (int[])intArray.clone();
  return temp;
 }
}   

// Main program class
class CloneDemo {

 // Display values in two containers side-by-side
 public static void showContainers(String msg, 
  IntContainer c1, IntContainer c2) {
  System.out.println("\n" + msg);
  for (int i = 0; i < c1.size(); i++) {
   System.out.print(i + " : " + c1.getValue(i) + "   \t");
   System.out.println(c2.getValue(i));
  }
 }

 public static void main(String args[]) {
  // Construct a container and randomize its content
  IntContainer original = new IntContainer(10);
  for (int i = 0; i < original.size(); i++)
   original.putValue(i, (int)(Math.random() * 100));
  try {
   // Clone the container
   IntContainer clone = (IntContainer)original.clone();
   showContainers("Before change", original, clone);  
   // Modify a value in the clone at index 1
   clone.putValue(1, clone.getValue(1) * 2);
   showContainers("After change", original, clone);
  } catch (CloneNotSupportedException e) {
   System.out.println(e.getMessage());
  }
 }
}
