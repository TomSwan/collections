//==============================================================
// TheInterface.java - Demonstrates basic interface design
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class MyException extends Exception { }

// Declare the interface (normally would be public)
interface MyInterface {
 void myMethod() throws MyException;
}

// Implement the interface
class MyImplementation
 implements MyInterface {
 public void myMethod() throws MyException {
  System.out.println("in myMethod()");
  throw new MyException();
 }
}

// Main program class
class TheInterface {
 public static void main(String args[]) {
  MyImplementation m = new MyImplementation();
  try { 
   m.myMethod();  // Exception always thrown
  } catch (MyException e) {
   System.out.println("MyException caught");
  }
 }
}
