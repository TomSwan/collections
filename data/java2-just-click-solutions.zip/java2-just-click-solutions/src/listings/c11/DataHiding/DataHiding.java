//==============================================================
// DataHiding.java - Demonstrate data hiding
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class TDate {
 private int month, day, year;
 public TDate(int month, int day, int year) {
  setDate(month, day, year);
 }
 public void setDate(int month, int day, int year) {
  this.month = month;
  this.day = day;
  this.year = year;
 }
 public String getDate() {
  return month + "/" + day + "/" + year;
 }
}

class DataHiding {
 public static void main(String args[]) {
  TDate birthday = new TDate(8, 15, 1975);
  String s = birthday.getDate();
  System.out.println("birthday = " + s);
 }
}
