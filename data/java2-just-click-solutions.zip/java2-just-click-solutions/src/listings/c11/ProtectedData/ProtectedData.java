//==============================================================
// ProtectedData.java - Demonstrate protected data members
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class TDate {
 protected int month, day, year;
 public TDate(int month, int day, int year) {
  setDate(month, day, year);
 }
 public void setDate(int month, int day, int year) {
  this.month = month;
  this.day = day;
  this.year = year;
 }
 public String getDate() {
  return month + "/" + day + "/" + year;
 }
}

class TDateTime extends TDate {
 protected int hour, min;
 public TDateTime(int month, int day, int year, 
  int hour, int min) {
  super(month, day, year);  // Call superclass constructor
  this.hour = hour;
  this.min = min;
 }
 public String getDate() {  // Override method
  return month + "/" + day + "/" + year +
   " : " + hour + ":" + min;
 }
}

class ProtectedData {
 public static void main(String args[]) {
  TDate now = new TDateTime(3, 15, 2001, 14, 45);
  String s = now.getDate();
  System.out.println("now = " + s);
 }
}
