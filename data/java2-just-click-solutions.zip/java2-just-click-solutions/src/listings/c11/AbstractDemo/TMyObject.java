//==============================================================
// TMyObject.java - Implement an abstract class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import TObject;

class TMyObject extends TObject {
 private String s;

// Constructor
 TMyObject(String s) {
  this.s = s;
 }

// Implement Comparable interface method
 public int compareTo(Object other) {
  TMyObject otherObject = (TMyObject)other;
  return s.compareTo(otherObject.s);
 }

// Implement TObject abstract method
 public void show() {
  System.out.print(s + "  ");
 }
}
