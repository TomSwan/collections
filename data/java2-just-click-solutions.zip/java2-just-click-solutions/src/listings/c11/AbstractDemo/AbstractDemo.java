//==============================================================
// AbstractDemo.java - Demonstrate using an abstract class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import TContainer;
import TMyObject;

class AbstractDemo {
 public static void main(String args[]) {
  TContainer container = new TContainer(100);
  try {
   container.putObject(new TMyObject("Peach"));
   container.putObject(new TMyObject("Mango"));
   container.putObject(new TMyObject("Lime"));
   container.putObject(new TMyObject("Banana"));
   container.putObject(new TMyObject("Kiwi"));
   container.putObject(new TMyObject("Grapefruit"));
   container.putObject(new TMyObject("Orange"));
   container.putObject(new TMyObject("Lemon"));
   container.putObject(new TMyObject("Apple"));
   container.showAllObjects("Before sorting");
   container.sort();
   container.showAllObjects("After sorting");
  } catch (ContainerFullException e) {
   System.out.println("Container overflow error");
  }
 }
}
