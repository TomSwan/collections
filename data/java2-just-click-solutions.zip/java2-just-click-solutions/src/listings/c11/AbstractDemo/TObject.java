//==============================================================
// TObject.java - Declare an abstract class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

abstract class TObject implements Comparable {
 abstract public int compareTo(Object other);
 abstract public void show();
}
