//==============================================================
// TContainer.java - Use an abstract class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import TObject;
import java.util.Arrays;

class ContainerFullException extends Exception { };

class TContainer {
// Private instance variables
 private int size;    // Size of objArray
 private int count;   // Count of objects in objArray
 private TObject objArray[];  // Array of objects

// Constructor (n = array size)
 public TContainer(int n) {
  if (n <= 0) n = 1;  // Minimum allowed size
  size = n;
  count = 0;
  objArray = new TObject[size];
 }

// Insert object into container
 public void putObject(TObject obj) 
  throws ContainerFullException {
  if (count >= size) 
   throw new ContainerFullException();
  objArray[count++] = obj;
 }

// Display all objects in container
 public void showAllObjects(String label) {
  System.out.println(label);
  for (int i = 0; i < count; i++)
   objArray[i].show();
  System.out.println();
 }

// Sort the objects in the container
 public void sort() {
  if (count > 1)
   Arrays.sort(objArray, 0, count);
 }
}
