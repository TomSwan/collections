//==============================================================
// Primes.java - Demonstrates Runnable interface
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.IOException;

class Background implements Runnable {
 
 boolean finished = false;  // True to end run()
 int num = 3;               // Prime number candidates
 int delay;                 // Time between each output

 // Constructor
 Background(int delay) {
  this.delay = delay;
 }

 // Return true if num is a prime number
 public boolean isPrime(int n) {
  for (int i = 2; i < n; i++)
   if ((n % i) == 0)
    return false;
  return true;
 }

 // Search for prime numbers in the background
 public void run() {
  try {
   while (!finished) {
    if (isPrime(num))
     System.out.println(num);
    num++;
    Thread.sleep(delay);
   } // while
  } catch (InterruptedException e) {
   return;
  }
 }

 // Set flag to stop run()
 public void halt() {
  finished = true;
 }

}

// Compute prime numbers in the background
class Primes {

 static char getChar() {
  char ch = '\0';
  try {
   ch = (char)System.in.read();
  } catch (IOException e) {
   System.out.println(e.getMessage());
  }
  return ch;
 }

 static void waitForKey(char key) {
  while (getChar() != key) /* wait */ ;
 }

 public static void main(String args[]) throws Exception {
  System.out.println("Press Enter to begin and again to quit");
  waitForKey('\n');
  // Construct and start thread
  Background background = new Background(50);
  Thread T = new Thread(background);
  T.setPriority(4);
  T.start();
  // Wait for Enter key while thread runs
  waitForKey('\n');
  background.halt();  // Stop the thread
 }
}
