//==============================================================
// Client.java - Class that feeds jobs to a server for processing
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Random;
import Job;
import Server;

class Client implements Runnable {

 Random rand = new Random();
 boolean finished = false;
 int jobcount = 0;

// Utility method creates a new numbered job with
// a random time delay to simulate how long the job takes
 private Job getAJob() {
  String name = "Job #" + ++jobcount;
  int delay = 1000 + rand.nextInt(9000);  // 1 .. 10 seconds
  Job j = new Job(name, delay);
  return j;
 }

 public void run() {

// Create the server daemon thread
  Server server = new Server();
  Thread T = new Thread(server);
  T.setDaemon(true);  // Server is a daemon!
  T.start();          // Start the server thread running

// Main run() actions
  try {
   while (!finished) {

   // Create a job and pass it to the server
    Job j = getAJob();  // Create simulated job object
    server.add(j);      // Returns immediately

   // Simulate user activity by sleeping a random time
    int time = 1000 + rand.nextInt(5000);
    System.out.println("Sleeping for " + 
     time / 1000 + " second(s)");
    Thread.currentThread().sleep(time);

   }
  } catch (InterruptedException e) {
   return;
  }
 }

// Halt the client
// However, all job threads finish to completion!
 public synchronized void halt() {
  finished = true;
  notifyAll();
 }
}
