//==============================================================
// LockDemo.java - Demonstrate object locks and synchonization
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.IOException;
import java.util.*;
import Client;
  
class LockDemo {

// Get a character from keyboard
 static char getChar() {
  char ch = '\0';
  try {
   ch = (char)System.in.read();
  } catch (IOException e) {
   System.out.println(e.getMessage());
  }
  return ch;
 }

// Wait for user to press a specified key
 static void waitForKey(char key) {
  while (getChar() != key) /* wait */ ;
 }

 public static void main(String args[]) {

// Construct and start the client (job creator) thread
  Client client = new Client();
  new Thread(client).start();

// Wait for Enter key so threads can run
  System.out.println("\n<<< Press Enter to end program >>>\n");
  waitForKey('\n');  // All threads run while waiting

// Halt the client thread; sever daemon also ends
// However, any remaining job threads finish to completion!
  client.halt();
 }
}
