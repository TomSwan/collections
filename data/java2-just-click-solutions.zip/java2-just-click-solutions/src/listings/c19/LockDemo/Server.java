//==============================================================
// Server.java - Server class queues and processes jobs using threads
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import Queue;
import Job;

class Server implements Runnable {

 Queue q = new Queue();  // Construct our Queue object 

 public void run() {
  try {
   doWhenReady();  // Do the server's activities
  } catch (InterruptedException e) {
   return;
  }
 }

// Perform server activities until shutdown
 private synchronized void doWhenReady()
  throws InterruptedException {
  for (;;) {              // Do "forever" loop
   while (q.isEmpty())    // Wait until there is a job in 
    wait();               //  the queue
   Job j = (Job)q.get();  // Get the job
   j.doJob();             // Do the job
  } // for
 }

// Add a new job to the server's queue
// This returns immediately; the job is not performed
// until the server thread detects the queue is no longer
// empty. 
 public synchronized void add(Job j) {
  q.add(j);
  notifyAll();
 }
}
