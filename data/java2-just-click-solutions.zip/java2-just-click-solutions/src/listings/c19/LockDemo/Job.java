//==============================================================
// Job.java - A Runnable class that does its own job in a thread
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

public class Job implements Runnable {

 private String name;    // Name of this job
 private int delay;      // How long it takes to do this job
 private boolean ready;  // True when job is ready to be done

// Constructor
 Job(String name, int delay) {
  this.name = name;
  this.delay = delay;
  ready = false;
  new Thread(this).start();  // Job runs itself in a thread!
 }

// Run method called by thread scheduler
 public void run() {
  try {
   doWhenReady();  // Do the job when it is ready
  } catch (InterruptedException e) {
   return;
  }
 }

// Performs the job's actual work
// Because this calls wait(), code cannot be in run()
// and it must be synchronized on this object
 private synchronized void doWhenReady()
  throws InterruptedException {
  while (!ready)
   wait();        // Wait indefinitely until ready
// Simulate the job by displaying messages and sleeping
// for the amount of time this job takes
  System.out.println("\nStarting " + name);
  System.out.println("Time = " + delay / 1000 + " second(s)");
  Thread.currentThread().sleep(delay);  // Simulate job runtime
  System.out.println("\nFinishing " + name);
  System.out.println("Ending thread " + toString());
 }

// Set the thread state flag to true 
// and notify all threads of the change
 public synchronized void doJob() {
  ready = true;
  notifyAll();
 }
}
