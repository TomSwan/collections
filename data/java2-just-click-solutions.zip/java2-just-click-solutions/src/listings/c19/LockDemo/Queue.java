//==============================================================
// Queue.java - Queue class with synchronized methods
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.LinkedList;

public class Queue {

 private LinkedList q = new LinkedList();

 public synchronized void add(Object o) {
  q.add(o);
 }

 public synchronized Object get() 
  throws InterruptedException {
  while (q.isEmpty())
   wait();
  return q.removeFirst();
 }

 public synchronized boolean isEmpty() {
  return q.isEmpty();
 }
}
