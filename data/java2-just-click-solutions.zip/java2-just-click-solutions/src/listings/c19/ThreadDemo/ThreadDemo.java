//==============================================================
// ThreadDemo.java - Demonstrates threaded programming
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.IOException;

// Extend Thread class and provide a run() method
class Background extends Thread {

 boolean finished;  // True when thread should die

 // Constructor
 Background(String name) {
  super(name);
  finished = false;  // Initialize run-flag
 }

 // Called by start() to run the thread
 public void run() {
  try {
   while (!finished) {   // Loop "forever"
    sleep(2000);
    System.out.println("\nHurry up!");
    sleep(1000);
    System.out.println("\nWhat's taking you so long?");
    sleep(1500);
    System.out.println("\nC'mon, press that Enter key!");
   }
  } catch (InterruptedException e) {
   return;  // End the thread
  }
 }

 // Halt the thread
 public void halt() {
  finished = true;  // Cause while loop in run() to end
  System.out.println("Stopping thread " + getName() + "\n");
 }
}

// Main program class demonstrates background processing
class ThreadDemo {
 public static void main(String args[]) {

// Create the background thread
  Background background = 
   new Background("Background process");
  System.out.println(
    "Starting thread. Press Enter to stop.");

// Start running the background thread
  background.start();

// Simulate foreground process: wait for Enter key
  try {
   while ((char)System.in.read() != '\n') ;
  } catch (IOException e) {
   System.out.println(e.getMessage());
  }

// Stop the background thread
  background.halt();
 }
}
