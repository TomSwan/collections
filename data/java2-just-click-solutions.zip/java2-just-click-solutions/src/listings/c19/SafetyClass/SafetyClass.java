//==============================================================
// SafetyClass.java - Illustrate synchronization and data hiding
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

// Illustration only: not a complete program
public class SafetyClass {

 private int counter;  // Private data in class

// Thread-safe method to write data
 public synchronized void setCounter(int n) {
  counter = n;         // Assign new value to counter
 }

// Thread-safe method to read data
 public synchronized int getCounter() {
  return counter;      // Return counter's current value
 }
}
