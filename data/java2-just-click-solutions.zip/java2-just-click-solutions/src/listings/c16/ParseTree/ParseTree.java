//==============================================================
// ParseTree.java - Demonstrate TreeSet container by parsing a file's words
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.*;
import java.io.*;

class ParseTree {
 public static void main(String args[]) {
// Variables
  int i;
  char c;
  StringBuffer sbuf = new StringBuffer();
  TreeSet hashTable = new TreeSet();

// Read and parse words from Quote.txt
  System.out.println();
  try {
   FileReader f = new FileReader("Quote.txt");
   while ((i = f.read()) >= 0) {
    c = (char)i;
    System.out.print(c);
    c = Character.toLowerCase(c);
    if (Character.isWhitespace(c)) {
     if (sbuf.length() > 0)
      hashTable.add(sbuf.toString());
     sbuf.setLength(0);
    } else 
    if (Character.isLetter(c))
     sbuf.append(c);
   }
   if (sbuf.length() > 0)
    hashTable.add(sbuf.toString());
  } catch (IOException e) {
   System.out.println("*** I/O error!");
  }

// Display hash table count and contents 
  System.out.println("\n");
  Iterator I = hashTable.iterator();
  String s;
  System.out.println("There are " + hashTable.size() 
   + " unique words in the file");
  while (I.hasNext()) {
   s = (String)I.next();
   System.out.println(s);
  }   
 }
}
