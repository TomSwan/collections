//==============================================================
// Successor.java - Finding an object's successor in a SortedSet container (e.g. TreeSet)
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.*;
import java.io.*;

class Successor {

// Return the successor of a SortedSet object or null if none
  static Object successorOf(SortedSet s, Object o) {
   SortedSet t = s.tailSet(o);
   if (t.size() < 2) return null;
   Iterator I = t.iterator();
   I.hasNext(); I.next(); I.hasNext();
   return I.next();
  }

// Return the inclusive set of SortedSet objects o1 through o2
  static SortedSet inclusiveSet(
    SortedSet s, Object o1, Object o2) {
   if (!s.contains(o1) || !s.contains(o2))
    throw new NoSuchElementException();
   Comparable c1 = (Comparable)o1;
   Comparable c2 = (Comparable)o2;
   if (c1.compareTo(c2) > 0) 
    throw new IllegalArgumentException();
   Object successor = successorOf(s, o2);
   if (successor == null)
    return s.tailSet(o1);
   else
    return s.subSet(o1, successor);
  }

// Display contents of a SortedSet container
 static void showSet(SortedSet S, String msg) {
  System.out.println("\n" + msg);
  Iterator I = S.iterator();
  while (I.hasNext())
   System.out.print("  " + I.next());
 }

 public static void main(String args[]) {
// Create the TreeSet container and add some objects to it
  TreeSet myTree = new TreeSet();
  myTree.add("Peach");
  myTree.add("Banana");
  myTree.add("Cherry");
  myTree.add("Apple");
  myTree.add("Pear");
  myTree.add("Kiwi");
  myTree.add("Grapefruit");

// Get a non-inclusive subset of the tree
  TreeSet subTree1 = 
   (TreeSet)myTree.subSet("Cherry", "Peach");

  TreeSet subTree2 =
   (TreeSet)inclusiveSet(myTree, "Cherry", "Peach");

// Display all tree sets  
  showSet(myTree, "Full TreeSet container:");
  showSet(subTree1, "Non-inclusive subset:");
  showSet(subTree2, "Inclusive subset:");
 }
}
