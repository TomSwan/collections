//==============================================================
// SubTree.java - Demonstrate the SortedSet.subSet() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.*;
import java.io.*;

class SubTree {
// Display contents of a SortedSet container
 static void showSet(SortedSet S, String msg) {
  System.out.println("\n" + msg);
  Iterator I = S.iterator();
  while (I.hasNext())
   System.out.print("  " + I.next());
 }

 public static void main(String args[]) {
// Create the TreeSet container and add some objects to it
  TreeSet myTree = new TreeSet();
  myTree.add("Peach");
  myTree.add("Banana");
  myTree.add("Cherry");
  myTree.add("Apple");
  myTree.add("Pear");
  myTree.add("Kiwi");
  myTree.add("Grapefruit");

// Get a non-inclusive subset of the tree
  TreeSet subTree = 
   (TreeSet)myTree.subSet("Cherry", "Peach");
// Get an inclusive subset of the tree
//  TreeSet subTree = 
//   (TreeSet)myTree.subSet("Cherry", "Peach\0");

// Display both trees  
  showSet(myTree, "Full TreeSet container:");
  showSet(subTree, "Subset of container:");
 }
}
