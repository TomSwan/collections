//==============================================================
// NestedTry.java - Demonstrate nested try blocks
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class NewException extends Exception { }
class NewNewException extends NewException { }

class NestedTry {
 public static void test() throws NewNewException {
  throw new NewNewException();
 }
 public static void main(String args[]) {
  try {
   try {
    test();
   } catch (NewNewException e) {
    System.out.println("Inner try block exception caught");
    throw e;  // Rethrow exception
   }
  } catch (NewException e) {
   System.out.println("Outer try block exception caught");
  }
 }
}
