//==============================================================
// StackTrace.java - Demonstrates Exception stack traces
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class NewException extends Exception { }

class StackTrace {
 // Cause an exception to be thrown
 public static void test() throws NewException {
  throw new NewException();
 }
 // Main program--catch the thrown exception
 public static void main(String args[]) {
  try {
   test();
  } catch (NewException e) {
   System.out.println("NewException caught. Tracing stack:");
   e.printStackTrace();  // Trace exception origin
  }
 }
}
