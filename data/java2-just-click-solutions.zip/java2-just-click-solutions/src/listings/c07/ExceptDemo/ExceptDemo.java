//==============================================================
// ExceptDemo.java - Demonstrates user exceptions
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class NewMathException extends Exception {
 // Constructor
 public NewMathException(double b, double e) {
  super("Domain error: base = " + b + " exp = " + e);
 }
}

final class NewMath {
 // Prevent instantiation of class
 private NewMath() { }
 // Return b raised to the power of e
 public static double power(double b, double e) 
 throws NewMathException {
  NewMathException error = new NewMathException(b, e);
  if (b > 0.0) return Math.pow(b, e);
  if (b < 0.0) {
   Double d = new Double(e);
   double ipart = d.intValue();
   double fpart = e - ipart;
   if (fpart == 0) {
    if ((ipart % 2) != 0)  // i.e. ipart is odd
     return -Math.pow(-b, e);
    else
     return Math.pow(-b, e);
   } else
    throw error;
  } else {
   if (e == 0.0) return 1.0;
   if (e < 1.0) throw error;
   return 0.0;
  }
 }
}

class ExceptDemo {
 public static void main(String args[]) {
  if (args.length < 2) {
   System.out.println("Specify value and exponent");
   System.out.println("ex. java ExceptDemo -4 1.5");
  } 
  else 
  try {
   double base = new Double(args[0]).doubleValue();
   double exponent = new Double(args[1]).doubleValue();
   double result = NewMath.power(base, exponent);
   System.out.println("Result = " + result);
  } catch (NewMathException e) {
   System.out.println(e.getMessage());
  }
 }
}
