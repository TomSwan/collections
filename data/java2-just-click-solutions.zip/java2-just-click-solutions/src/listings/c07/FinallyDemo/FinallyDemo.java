//==============================================================
// FinallyDemo.java - Demonstrate try-catch-finally statements
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

// Exception class
class ThrowMe extends Exception {
 ThrowMe() { }
 ThrowMe(String s) {
  super(s); 
 }
}

class FinallyDemo {
 // Test method -- pass 0, 1, or 2 for different exceptions
 static void testMethod(int n) throws Exception, ThrowMe {
  switch (n) {
  case 1: 
   throw new Exception("Unhandled exception");
  case 2:
   throw new ThrowMe("To the wolves");
  default:
   return;
  }
 }
 // Main program 
 public static void main(String args[]) 
  throws Exception {
  int argument = 0;
  if (args.length > 0)
   argument = Integer.parseInt(args[0]);
  try {
   testMethod(argument);
  } catch (ThrowMe e) {
   System.out.println("ThrowMe: " + e.getMessage());
  } finally {
   System.out.println("Finally statement");
  }
  System.out.println("Statement after try block");
 }
}
