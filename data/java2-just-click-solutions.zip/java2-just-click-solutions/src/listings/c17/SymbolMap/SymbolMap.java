//==============================================================
// SymbolMap.java - Demonstrate HashMap container
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.*;
import java.io.*;

class SymbolMap {

// Display a Map container's keys and values
 public static void showMap(Map m) {
  Iterator I = m.entrySet().iterator();
  while (I.hasNext()) {
// Get next Map.Entry object
   Map.Entry entry = (Map.Entry)I.next();
   System.out.println(
    entry.getKey() + "\t:: " + entry.getValue());
  }
 }

 public static void main(String args[]) {
// Create a HashMap container and insert some associations
  HashMap symbols = new HashMap();
  symbols.put(new Integer( 34), "Double quote");
  symbols.put(new Integer( 37), "Percent");
  symbols.put(new Integer( 38), "Ampersand");
  symbols.put(new Integer( 60), "Less than");
  symbols.put(new Integer( 62), "Greater than");
  symbols.put(new Integer(162), "Cent");
  symbols.put(new Integer(163), "Pound");
  symbols.put(new Integer(169), "Copyright");
  symbols.put(new Integer(247), "Divide");

// Print database or search for requested key
  if (args.length == 0) {
   showMap(symbols);
  } else {
   int key = Integer.parseInt(args[0]);
   String value = (String)symbols.get(new Integer(key));
   if (value == null)
    System.out.println(key + " not in symbols");
   else
    System.out.println(key + " == " + value);
  }
 }
}
