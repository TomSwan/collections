//==============================================================
// Dictionary.java - Create dictionary using TreeMap and LinkedList
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.*;
import java.io.*;

class Dictionary {

// Construct TreeMap dictionary container
  static TreeMap dict = new TreeMap();

// Lookup and show definition for the specified word (key)
 static void showDefinition(String word) {
  LinkedList defs = (LinkedList)dict.get(word);
  if (defs == null) return;  // Ignore if not there
  ListIterator L = defs.listIterator();
  int count = 1;  // Definition counter
  System.out.println("\n" + word);
  while (L.hasNext()) {
    String definition = (String)L.next();
    System.out.println(count++ + ". " + definition);
  }   
 }

// Display entire dictionary
 static void showDictionary() {
  Iterator I = dict.keySet().iterator();
  while (I.hasNext())
   showDefinition((String)I.next());
 }

// Add a new word and/or definition
 static void addWord(String word, String definition) {
  if (dict.containsKey(word)) {
   LinkedList defs = (LinkedList)dict.get(word);
   defs.add(definition);  // Add new definition only
  } else {
   LinkedList defs = new LinkedList();  // New list
   defs.add(definition);  // Add definition to new list
   dict.put(word, defs);  // Add word and defs association
  }
 }

 public static void main(String args[]) {

// Read words and definitions into the container
  try {
   FileReader fr = new FileReader("Dictionary.txt");
   BufferedReader br = new BufferedReader(fr);
   String word = br.readLine();
   while (word != null) {
    addWord(word, br.readLine());  // Add word and definition
    br.readLine();         // Skip blank line
    word = br.readLine();  // Read next word
   }
  } catch (FileNotFoundException e) {
   System.out.println("File not found: " + e.getMessage());
  } catch (IOException e) {
   System.out.println("I/O error: " + e.getMessage());
  }

// Look up one word or show entire dictionary
 if (args.length == 0)
  showDictionary();         // Show all
 else
  showDefinition(args[0]);  // Show selection

 }  // main
} // class
