//==============================================================
// DateShow.java - Demonstrates inheriting classes
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Date;  // Import the Date class

// Extend the imported Date class
class NewDate extends Date {
 public void display() {
  System.out.println(toString());
 }
}

// Use the NewDate class
class DateShow {
 public static void main(String args[]) {
  NewDate today = new NewDate();  // Construct NewDate object
  today.display();  // Call the new display() method
 }
}
