//==============================================================
// InputDemo.java - Demonstrates string input
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.IOException;

class InputDemo {
 public static void main(String args[]) {
  try {
   // Input a single character
   System.out.println("Type a character:");
   char ch = (char)System.in.read();
   System.out.println("You entered: " + ch);
   // Throw out new line
   while (ch != '\n')
    ch = (char)System.in.read();  
   // Input a string
   System.out.println("Type a string:");
   StringBuffer s = new StringBuffer();
   while ((ch = (char)System.in.read()) != '\n')
    s.append(ch);
   System.out.println("You entered: " + s);
  } catch (IOException e) {
   System.out.println("Input error detected");
  }
 }
}
