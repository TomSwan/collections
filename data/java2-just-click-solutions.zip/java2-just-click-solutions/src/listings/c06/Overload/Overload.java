//==============================================================
// Overload.java - Demonstrates overloaded functions
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class DemoClass {
 // Method #1
 void show(int x) {
  System.out.println("int x = " + x);
 }
 // Method #2
 void show(double x) {
  System.out.println("double x = " + x);
 }
 // Method #3
 void show(char x) {
  System.out.println("char x = " + x);
 }
}

class Overload {
 public static void main(String args[]) {
  DemoClass myObj = new DemoClass();  // Create object
  myObj.show(123);      // Call show() #1
  myObj.show(3.14159);  // Call show() #2
  myObj.show('Q');      // Call show() #3
 }
}
