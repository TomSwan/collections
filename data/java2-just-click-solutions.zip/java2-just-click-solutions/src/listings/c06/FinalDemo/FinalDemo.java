//==============================================================
// FinalDemo.java - Demonstrate finalize() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class AnyClass {
 AnyClass() {
  System.out.println("Inside AnyClass() constructor");
 }
 protected void finalize() {
  System.out.println("Inside AnyClass() finalize method");
 }
}

class FinalDemo {
 public static void f() {
  System.out.println("Start method f()");
  AnyClass obj1 = new AnyClass();
  System.out.println("End method f()");
 }
 public static void main(String args[]) {
  System.out.println("Start method main()");
  f();
  AnyClass obj2 = new AnyClass();
  System.out.println("End method main()");
 }
}
