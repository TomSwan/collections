//==============================================================
// DateDemo.java - Demonstrates importing classes
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Date;  // Import the Date class

// Use the imported Date class
class DateDemo {
 public static void main(String args[]) {
  Date today = new Date();
  System.out.println(today.toString());
 }
}
