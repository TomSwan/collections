//==============================================================
// Methods.java - Demonstrate class methods
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

// Method demonstration class
class MethodClass {
 int sum(int a, int b, int c) {
  return a + b + c;
 }
 double product(double x, double y) {
  return x * y;
 }
 void showErrorMessage(int code) {
  switch (code) {
  case 1:
   System.out.println("Error 1: Deep trouble!");
   break;
  case 2:
   System.out.println("Error 2: Deeper trouble!");
   break;
  default:
   System.out.println("Unknown code: Situation hopeless");
  }
 }
}

// Main program class
class Methods {
 public static void main(String args[]) {
  // Create demo object of the MethodClass class
  MethodClass demo = new MethodClass();

  // Call demo object's sum() method
  int k = demo.sum(10, 25, 16);
  System.out.println("sum = " + k);

  // Call demo object's product() method
  double f = demo.product(3.14159, 4.5);
  System.out.println("product = " + f);

  // Call demo object's showErrorMessage() method
  demo.showErrorMessage(1);
  demo.showErrorMessage(2);
 }
}
