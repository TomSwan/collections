//==============================================================
// OutputDemo.java - Demonstrates string output
// Copyright (c) 1997 by Tom Swan. All rights reserved.
//==============================================================

class OutputDemo {
 public static void main(String args[]) {
  StringBuffer s = new StringBuffer();
  for (char c = 'A'; c <= 'Z'; c++) {
   s.append(c);
  }
  System.out.println(s);  // Displays the alphabet
 }
}
