//==============================================================
// Serial.java - Use static data and method to serialize objects
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class Serialized {
 static private int nextSerialNum;  // Initialized to 0
 private int serialNum;
 // Construct a Serialized object
 Serialized() {
 // Increment and assign serial number to an object
  serialNum = ++nextSerialNum;
 }
 // Show the object's serial number
 public void showSerialNumber(String name) {
  System.out.println(name + "'s serial number = " + serialNum);
 }
}

class Serial {
 public static void main(String args[]) {
  Serialized obj1 = new Serialized();
  Serialized obj2 = new Serialized();
  Serialized obj3 = new Serialized();
  obj1.showSerialNumber("Object 1");
  obj2.showSerialNumber("Object 2");
  obj3.showSerialNumber("Object 3");
 }
}
