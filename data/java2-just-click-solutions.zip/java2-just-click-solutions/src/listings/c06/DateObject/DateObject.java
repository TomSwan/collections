//==============================================================
// DateObject.java - Demonstrates class objects
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

// Declare DateClass
class DateClass {
 int month;
 int day;
 int year;
 public DateClass(int m, int d, int y) {
  month = m;
  day = d;
  year = y;
  // year = y + 1900;
 }
 public void display() {
  System.out.println(month + "/" + day + "/" + year);
 }
}

// Declare main program class
class DateObject {
 public static void main(String args[]) {
  // Create and display a DateClass object
  DateClass birthday = new DateClass(7, 18, 64);
  birthday.display();
  // Create and display another DateClass object
  DateClass future = new DateClass(1, 1, 01);
//  DateClass future = new DateClass(1, 1, 101);
  future.display();
 }
}
