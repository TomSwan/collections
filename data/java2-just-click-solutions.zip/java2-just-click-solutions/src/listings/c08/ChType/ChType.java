//==============================================================
// ChType.java - Determines type and numeric value of characters
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class ChType {

 // Display type of ch (not all types listed)
 public static void showType(char ch) {
  int type = Character.getType(ch);
  String s;
  switch (type) {
   case Character.UPPERCASE_LETTER:
    s = "uppercase letter"; break;
   case Character.LOWERCASE_LETTER:
    s = "lowercase letter"; break;
   case Character.DECIMAL_DIGIT_NUMBER:
    s = "decimal digit number"; break;
   case Character.OTHER_PUNCTUATION:
    s = "punctuation symbol"; break;
   case Character.MATH_SYMBOL:
    s = "math symbol"; break;
   case Character.CURRENCY_SYMBOL:
    s = "currency symbol"; break;
   default:
    s = "unknown symbol";
  }
  System.out.println("char " + ch + " : " + s +
    " (" + (int)ch + ")");
 }

 public static void main(String args[]) {
  showType('A');
  showType('z');
  showType('3');
  showType('!');
  showType('+');
  showType('$');
  showType('\u0123');
 }
}
