//==============================================================
// InputString.java - Prompts for and reads a string
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.IOException;

class InputString {
 public static void main(String args[]) {
  try {
   StringBuffer buffer = new StringBuffer(64);
   char ch;
 // Prompt for and read a string
   System.out.print("Type something: ");
   while ((ch = (char)System.in.read()) != '\n')
    buffer.append(ch);  // Build string using ch
   // Display string entered
   System.out.println("You entered: " + buffer);
  } catch (IOException e) {            // Trap exception
   System.out.println(e.toString());   // Display error
  }
 }
}
