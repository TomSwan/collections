//==============================================================
// NullString.java - How to avoid a NullPointerException
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class NullString {
 // Return a null string reference
 public static String badString() {
  String s = null;
  return s;
 }
 // Return a zero-length string
 public static String goodString() {
  String s = new String();
  return s;
 }
 // Try the preceding two methods
 // The NullPointerException is intentional
 public static void main(String args[]) {
  String s;
  s = badString();  // Change to goodString() and rerun
  System.out.println("Length(s) = " + s.length());
 }
}
