readme.txt

The NullString.java program intentionally produces a 
NullPointerException. Change the call to badString()
to goodString() in method main() and rerun. See the
text for an further explanation.
