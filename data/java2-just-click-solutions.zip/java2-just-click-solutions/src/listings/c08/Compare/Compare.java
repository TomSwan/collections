//==============================================================
// Compare.java - Demonstrates compareTo() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class Compare {
 public static void main(String args[]) {
 String s1 = "abcdefg";
 String s2 = "ABCDEFG";
 int result = s1.compareTo(s2);
 if (result == 0)
  System.out.println("s1 = s2");
 else if (result < 0)
  System.out.println("s1 < s2");
 else // if (result > 0)
  System.out.println("s1 > s2");
 }
}
