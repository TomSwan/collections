//==============================================================
// CharEncoding.java - Convert byte array to String using character encoding
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.io.UnsupportedEncodingException;

class CharEncoding {
  public static void main(String args[]) {
  String s;
  byte byteArray[] = new byte[26];
  for (int i = 0; i < 26; i++)
   byteArray[i] = (byte)(i + 'a');
// Convert byte array to a String using an encoding
  try {
   s = new String(byteArray, "UTF-8");
   System.out.println(s);
  } catch (UnsupportedEncodingException e) {
   System.out.println(e.getMessage());
  }
 }
}
