//==============================================================
// ChRadix.java - Demonstrate Character class RADIX constants
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class ChRadix {
 public static void main(String args[]) {
  System.out.println("Min radix = " + Character.MIN_RADIX);
  System.out.println("Max radix = " + Character.MAX_RADIX);

  int radix = 12, result;
  char ch = '0';
  if (Character.MIN_RADIX <= radix && 
      radix <= Character.MAX_RADIX) {
   while (ch <= 'Z') {
    result = Character.digit(ch, radix);
    if (result >= 0)
      System.out.println(
       ch + " in base " + radix + " = " + result);
    else
     System.out.println("Char " + ch + " undefined for radix");
    if (ch == '9')
     ch = 'A';
    else
     ch++;
   } // while
  } else
   System.out.println("Radix " + radix + " out of range");
 }
}
