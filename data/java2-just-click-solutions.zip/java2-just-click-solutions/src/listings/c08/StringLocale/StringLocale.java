//==============================================================
// StringLocale.java - Demonstrates using a Locale with a String
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.util.Locale;

class StringLocale {
 public static void main(String args[]) {
 String s = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
 System.out.println("Before : " + s);
 s = s.toLowerCase(Locale.CANADA);
 System.out.println("After  : " + s);
 }
}
