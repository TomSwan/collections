//==============================================================
// Concat.java - Demonstrates concat() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class Concat {
 public static void main(String args[]) {
  String s1 = " One";
  String s2 = " Two";
  String s3 = " Three";
  String test = "Testing";
  test = test.concat(s1);
  test = test.concat(s2);
  test = test.concat(s3);
  System.out.println(test);
 }
}
