//==============================================================
// MonthNames.java - Demonstrates substring() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class MonthNames {
 public static void main(String args[]) {
  String s = "#January#February#March#April" +
"#May#June#July#August#September#October" +
"#November#December#";
  int i = 0, j;
  while (i++ >= 0) {
   j = s.indexOf('#', i);  // i = starting index
   if (j >= 0) {
    String month = s.substring(i, j);
    System.out.println(month);
   }
   i = j;
  }
 }
}
