//==============================================================
// CharArray.java - Construct a string from a char array
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class CharArray {
  public static void main(String args[]) {
  String s;
  char array[] = new char[26];
  for (char c = 'a'; c <= 'z'; c++)
   array[c - 'a'] = c;
  s = new String(array);
  System.out.println(s);
 }
}
