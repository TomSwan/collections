//==============================================================
// StringAppend.java - Demonstrate StringBuffer.append() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class StringAppend {
 public static void main(String args[]) {
  // Declare and initialize a StringBuffer object
  StringBuffer buffer = new StringBuffer(80);
  // Declare some variables of different types
  boolean truth = false;
  long value = 1000000;
  char ch = '$';
  // Append literal strings and variables to buffer
  buffer.append("You won ");
  buffer.append(ch);
  buffer.append(value);
  buffer.append(" is a ");
  buffer.append(truth);
  buffer.append(" statement!");
  // Display the result
  System.out.println(buffer);
 }
}
