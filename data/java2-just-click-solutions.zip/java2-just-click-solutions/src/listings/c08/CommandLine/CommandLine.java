//==============================================================
// CommandLine.java - Demonstrates command-line arguments
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class CommandLine {
 public static void main(String args[]) {
  System.out.println("Number of arguments = " + args.length);
  for (int i = 0; i < args.length; i++) {
   System.out.println(args[i]);
  }
 }
}
