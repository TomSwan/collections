//==============================================================
// StringTrimmer.java - Trim leading and trailing blanks from a string
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class StringTrimmer {
 public static void main(String args[]) {
  String s = "    blankety blank    ";
  System.out.println("Length before = " + s.length());
  s = s.trim();  // trim blanks from string
  System.out.println("Length after  = " + s.length());
 }
}
