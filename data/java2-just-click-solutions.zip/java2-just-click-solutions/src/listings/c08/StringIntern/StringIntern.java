//==============================================================
// StringIntern.java - Demonstrate the String.intern() method
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

class StringIntern {
 public static void main(String args[]) {
  String s1 = "Unique string";
  String s2 = s1.intern();
  if (s1 == s2) 
    System.out.println("s1 equals s2");
 }
}
