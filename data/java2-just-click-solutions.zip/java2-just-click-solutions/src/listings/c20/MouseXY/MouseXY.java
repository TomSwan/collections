//==============================================================
// MouseXY.java - Demonstrates old style AWT handleEvent() method
// Copyright (c) 1997 by Tom Swan. All rights reserved.
//==============================================================

import java.applet.*;
import java.awt.*;

public class MouseXY extends Applet {
 String location;  // String for X=0 Y=0 display

 // Initialize applet variables and window
 public void init() {
  setBackground(Color.yellow);
  resize(200, 100);
  location = new String("Move mouse inside window");
 }

 // Paint the location string inside window
 public void paint(Graphics g) {
  g.drawString(location, 10, 10);
 }

 // Create the location string from x and y
 public void makeString(int x, int y) {
  location = new String(
   " X=" + String.valueOf(x) +
   " Y=" + String.valueOf(y) );
 }

 // Handle all events for this applet
 public boolean handleEvent(Event  evt) {
  boolean eventHandled = false;
  switch (evt.id) {
   case Event.MOUSE_DOWN:
   case Event.MOUSE_UP:
   case Event.MOUSE_DRAG:
   case Event.MOUSE_ENTER:
   case Event.MOUSE_MOVE: {
    makeString(evt.x, evt.y);
    repaint();
    eventHandled = true;
    break;
   }
   case Event.MOUSE_EXIT: {
    location = new String("Move mouse inside window");
    repaint();
    eventHandled = true;
   }
  }
  if (eventHandled)
   return true;
  else
   return super.handleEvent(evt);
 }
}
