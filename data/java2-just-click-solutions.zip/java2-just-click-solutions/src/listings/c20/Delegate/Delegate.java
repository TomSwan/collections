//==============================================================
// Delegate.java - Demonstrate the AWT delegation event model
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

public class Delegate extends Applet {

// Define two AWT button objects
 private Button button1 = new Button("Click This!");
 private Button button2 = new Button("Click Me!");

 // Declare an inner class for the listener object
 // Toggles between the two buttons
 class ButtonListener implements ActionListener {
  public void actionPerformed(ActionEvent e) {
   if (e.getActionCommand().equals("button1action")) {
    button1.setEnabled(false);
    button2.setEnabled(true);
   } else {
    button1.setEnabled(true);
    button2.setEnabled(false);
   }
  }
 }

// Applet class constructor
 public Delegate() {
  ButtonListener actionObject = new ButtonListener();
  button1.setActionCommand("button1action");
  button1.addActionListener(actionObject);
  button2.setActionCommand("button2action");
  button2.addActionListener(actionObject);
  button1.setEnabled(true);
  button2.setEnabled(false);
  add(button1);
  add(button2);
 }
}
