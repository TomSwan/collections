//==============================================================
// RandomColor.java - Delegation event model using anonymous class
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class RandomColor extends Applet {
 
 // Constructor 
 public RandomColor() {
  // Create GUI button object and random generator
  Button clickMe = new Button("Click Me!");
  final Random gen = new Random();

  // Create listener using an anonymous class
  clickMe.addActionListener(new ActionListener() {
   public void actionPerformed(ActionEvent e) {
    Color c;
    do {
     c = new Color(gen.nextInt());
    } while (c == getBackground());
    setBackground(c);
    repaint();
   }
  });

  // Add button to Applet container
  add(clickMe);
 }
}
