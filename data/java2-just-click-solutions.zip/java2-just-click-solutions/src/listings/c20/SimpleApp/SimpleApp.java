//==============================================================
// SimpleApp.java - A minimal AWT application
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.awt.*;

public class SimpleApp {
 public static void main(String args[]) {
  System.out.println("Creating application window...");
  Frame f = new Frame("Application Frame Window");
  String s = "Press Ctrl+C to close this window!";
  f.add(new TextArea(s, 4, s.length()));
  f.pack();
  f.show();
 }
}
