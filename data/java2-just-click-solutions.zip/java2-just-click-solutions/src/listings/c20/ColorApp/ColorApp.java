//==============================================================
// ColorApp.java - Delegation event model AWT application
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class ColorApp
 extends Panel 
 implements ActionListener {

 protected Random gen = new Random();
 
 // Constructor 
 public ColorApp() {
  Button clickMe = new Button("Click Me!");
  clickMe.addActionListener(this);
  add(clickMe);  // Add button to panel
 }

 // The button's event handler
 public void actionPerformed(ActionEvent e) {
  Color c;
  do {
   c = new Color(gen.nextInt());
  } while (c == getBackground());
  setBackground(c);
  repaint();
 }

 // The main program
 public static void main(String[] args) {

  // Create frame and set its size
  Frame frame = new Frame("Color Application Demo");
  frame.setSize(250, 200);
  frame.setLocation(50, 50);

  // End the program when the window is closed
  frame.addWindowListener(new WindowAdapter() {
   public void windowClosing(WindowEvent e) {
    System.exit(0);
   }
  });

  // Add the ColorApp panel to the frame and show it
  frame.add(new ColorApp(), BorderLayout.CENTER);
  frame.show();
 }
}
