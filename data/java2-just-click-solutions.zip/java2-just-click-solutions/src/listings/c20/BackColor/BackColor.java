//==============================================================
// BackColor.java - AWT Applet using old inheritance event model
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.applet.Applet;
import java.awt.*;
import java.util.Random;

public class BackColor extends Applet {
 Random gen;  // Random number generator for color selction
 String buttonLabel = "Click Me!";

 // Initialize applet
 public void init() {
  gen = new Random();
  Button colorButton = new Button(buttonLabel);
  add(colorButton);  // Added to Applet container
 }

 // Respond to button click
 public boolean action(Event evt, Object what) {
  Color c;
  if (buttonLabel.equals(what)) {  // Is it our button?
   do {
    c = new Color(gen.nextInt());
   } while (c == getBackground());
   setBackground(c);
   repaint();
  }
  return true;  // Kill event
 }
}
	
