Readme.txt
1:55 PM 3/17/01

You receive a warning when compiling BackColor.java. 
This is intentional, because the program demonstrates
the old JDK 1.0 event model. Following is the explanation
of this warning from Chapter 20:

Compiling the demonstration program with the command 

javac BackColor.java 

produces a "deprecation" warning. Use the command-line option 
-deprecation to show that this happens because of the deprecated 
action() method. The program still compiles correctly, and it 
runs harmlessly, but the compiler warns you that it uses the old 
style inheritance event model.
