//==============================================================
// AppletADay.java - Demonstrates simple applet programming.
// Copyright (c) 2001 by Tom Swan. All rights reserved.
//==============================================================

import java.applet.Applet;
import java.awt.Color;
import java.awt.TextArea;

public class AppletADay extends Applet {
// This method initializes the Applet
 public void init() {
  setBackground(Color.gray);
  String s = "An Applet a Day Keeps the Debugger Away!";
  add(new TextArea(s, 4, s.length()));
 }
}
