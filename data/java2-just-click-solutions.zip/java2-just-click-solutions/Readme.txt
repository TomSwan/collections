Java 2 Just Click! Solutions
Readme.txt
5:28 PM 5/26/01

1. The formats for the interactive Just Click! indexes were updated just 
before this book went to press. Some of the screen shots on the cover and
in Chapter 2 differ in minor ways from what you see onscreen.

2. For best results, copy the index.html, help.html, cover.jpg, and Readme.txt
files from the outer CD-ROM directory to a new directory on your hard drive.
Also copy the src subdirectory, along with all of its contents. You may name
your directory as you wish (I named mine j2jc for Java 2 Just Click!), but 
the subdirectory must be named src.

3. To browse the listings, simply open index.html using your favorite Web
browser. Click the help command on the main menu for additional instructions
and suggestions for using the online indexes and files.

4. If you find any errors, please send me an email. Please limit your questions
to one or two, and do not send large files. Check my web site for updates and for 
information about my other books. I welcome all suggestions for improving my 
Web site and this book.

Thank you very much for trying Java 2 Just Click! Solutions.

Tom Swan
www.tomswan.com
