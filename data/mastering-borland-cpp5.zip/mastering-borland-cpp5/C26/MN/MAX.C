/* max.c -- Note: MUST be a C, not a C++, program! */
#include <stdio.h>
#include <stdlib.h>
main()
{
  int a = 9, b = 45;
  int c = max(a, b);
  printf("max(%d, %d) == %d\n", a, b, c);
  return 0;
}
