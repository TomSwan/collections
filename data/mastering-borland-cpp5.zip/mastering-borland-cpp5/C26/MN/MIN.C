/* min.c -- Note: MUST be a C, not a C++, program! */
#include <stdio.h>
#include <stdlib.h>
main()
{
  int a = 9, b = 45;
  int c = min(a, b);
  printf("min(%d, %d) == %d\n", a, b, c);
  return 0;
}
