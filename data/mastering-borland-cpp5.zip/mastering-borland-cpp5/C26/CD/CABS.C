/* cabs.c */
#include <stdio.h>
#include <math.h>
main()
{
  struct complex z = {2.0, 1.0};
  double result;
  result = cabs(z);
  printf("cabs(%.2lf:%.2lf) == %.2lf", z.x, z.y, result);
  return 0;
}
