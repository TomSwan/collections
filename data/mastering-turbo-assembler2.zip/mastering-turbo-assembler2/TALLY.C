/* TALLY.C -- A Short Inline Assembly Language Example */

#include <stdio.h>

int main(void)
{
  int votes;
  int tally;

  votes = 100;
  tally = 500;
  printf("Tally : %d\n", tally);
  asm mov ax, [votes];
  asm add [tally], ax;
  printf("Tally : %d\n", tally);
  return 0;
}
