#pragma inline
#include <stdio.h>

void showflags(void);

int main()
{
  showflags();
  return 0;
}

void showflags(void)
{
  unsigned int theflags;

  printf("- - - - O D I T S Z - A - P - C\n");
  asm pushf                       /* push flags onto stack */
  asm pop [theflags]              /* pop flags into theflags */
  asm mov cx, 16                  /* assign loop count to cx */
Again:
  asm rol [Word ptr theflags], 1  /* rotate bit to LSD position */
  asm push cx                     /* save loop count on stack */
  printf("%d ", (theflags & 1));  /* display value of LSD */
  asm pop cx                      /* restore saved loop count */
  asm loop Again                  /* repeat until done */
  printf("\n");                   /* start new output line */
}
