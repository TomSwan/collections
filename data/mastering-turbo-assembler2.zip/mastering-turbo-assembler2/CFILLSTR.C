/* Test CFILLSTR External Module -- by Tom Swan */

#include <stdio.h>
#include <string.h>

extern void fillstring(unsigned char far * thestring,
  int stringlength, char fillchar);

char *test = "Filled to the brim";

int main()
{
  printf("Before fillstring:  %s\n", test);
  fillstring( test, strlen(test), '@' );
  printf("After fillstring:   %s\n", test);
  return 0;
}

/*
void fillstring( unsigned char far * thestring,
  int stringlength, char fillchar )
{
  int i;

  for (i = 0; i < stringlength; i++)
    thestring[ i ] = fillchar;
}
*/
