Programmer's Guide to the 1802 PDF edition
Copyright (c) 1981, 2013 by Tom Swan, All Rights Reserved
Readme.txt 01Jun2013

Hi and thank you for purchasing the eBook edition of my book, Programmer's 
Guide to the 1802, originally published in 1981 by Hayden Book Company. In 
this Zip file, you will find this Readme.txt file, plus two others:

1. Programmer'sGuideToThe1802.pdf -- This is a facsimile of the original 
book, cover to cover.

2. Programmer'sGuideToThe1802_OCR.pdf -- This is a text-searchable version 
of the same book, again a cover-to-cover replica.

Use the first PDF file if you need an exact photocopy of the original 
book. Use the second (OCR) file if you want to search the contents of the 
book. 

I cannot give instructions for all the various PDF reader programs out 
there, but many recognize Ctrl-F as the "Find" command key. Open the OCR 
PDF file using your favorite PDF reader, or open the file inside your 
Internet browser. Press Ctrl-F and then type an argument -- for example, an 
1802 instruction such as SEX, which as everyone knows is shorthand for 
"Set the X Register." By the way, the book's text, all programming 
examples, plus the various reference materials are fully searchable!

NOTE: Please don't share Programmer's Guide to the 1802 PDF files. If you 
received the PDF files without purchasing them, please go to 
www.tomswan.com and buy your own copy from my online store (price for both 
PDFs is $10.00 U.S dollars). Thank you for your honesty!

Best Wishes,
Tom Swan
www.tomswan.com

Problems? Send an email to support@tomswan.com. I'll try to answer all questions as soon as possible.
